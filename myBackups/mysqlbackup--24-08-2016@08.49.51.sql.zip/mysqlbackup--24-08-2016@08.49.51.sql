--
-- Database : aplikasi_toko
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `akses`
--
DROP TABLE  IF EXISTS `akses`;
CREATE TABLE `akses` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `otoritas` varchar(100) NOT NULL,
  `akses` varchar(100) NOT NULL,
  `fungsi` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=629 DEFAULT CHARSET=latin1;

INSERT INTO `akses`  VALUES ( "252","Purchasing","Persediaan","Lihat");
INSERT INTO `akses`  VALUES ( "253","Purchasing","Persediaan","Tambah");
INSERT INTO `akses`  VALUES ( "254","Purchasing","Persediaan","Hapus");
INSERT INTO `akses`  VALUES ( "255","Purchasing","Persediaan","Edit");
INSERT INTO `akses`  VALUES ( "264","Purchasing","Item","Lihat");
INSERT INTO `akses`  VALUES ( "265","Purchasing","Item","Tambah");
INSERT INTO `akses`  VALUES ( "266","Purchasing","Item","Hapus");
INSERT INTO `akses`  VALUES ( "267","Purchasing","Item","Edit");
INSERT INTO `akses`  VALUES ( "292","Waiters","Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "293","Waiters","Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "294","Waiters","Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "299","Accounting","Pembayaran Hutang","Lihat");
INSERT INTO `akses`  VALUES ( "300","Accounting","Pembayaran Hutang","Tambah");
INSERT INTO `akses`  VALUES ( "301","Accounting","Pembayaran Hutang","Hapus");
INSERT INTO `akses`  VALUES ( "302","Accounting","Pembayaran Hutang","Edit");
INSERT INTO `akses`  VALUES ( "303","Accounting","Pembayaran","Lihat");
INSERT INTO `akses`  VALUES ( "304","Accounting","Pembayaran Piutang","Lihat");
INSERT INTO `akses`  VALUES ( "305","Accounting","Pembayaran Piutang","Tambah");
INSERT INTO `akses`  VALUES ( "306","Accounting","Pembayaran Piutang","Hapus");
INSERT INTO `akses`  VALUES ( "307","Accounting","Pembayaran Piutang","Edit");
INSERT INTO `akses`  VALUES ( "308","Accounting","Transaksi Kas","Lihat");
INSERT INTO `akses`  VALUES ( "309","Accounting","Transaksi Kas","Tambah");
INSERT INTO `akses`  VALUES ( "310","Accounting","Transaksi Kas","Hapus");
INSERT INTO `akses`  VALUES ( "311","Accounting","Transaksi Kas","Edit");
INSERT INTO `akses`  VALUES ( "312","Accounting","Transaksi Kas Masuk","Lihat");
INSERT INTO `akses`  VALUES ( "313","Accounting","Transaksi Kas Masuk","Tambah");
INSERT INTO `akses`  VALUES ( "314","Accounting","Transaksi Kas Masuk","Hapus");
INSERT INTO `akses`  VALUES ( "315","Accounting","Transaksi Kas Masuk","Edit");
INSERT INTO `akses`  VALUES ( "316","Accounting","Transaksi Kas Keluar","Lihat");
INSERT INTO `akses`  VALUES ( "317","Accounting","Transaksi Kas Keluar","Tambah");
INSERT INTO `akses`  VALUES ( "318","Accounting","Transaksi Kas Keluar","Hapus");
INSERT INTO `akses`  VALUES ( "319","Accounting","Transaksi Kas Keluar","Edit");
INSERT INTO `akses`  VALUES ( "320","Accounting","Transaksi Kas Mutasi","Lihat");
INSERT INTO `akses`  VALUES ( "321","Accounting","Transaksi Kas Mutasi","Tambah");
INSERT INTO `akses`  VALUES ( "322","Accounting","Transaksi Kas Mutasi","Hapus");
INSERT INTO `akses`  VALUES ( "323","Accounting","Transaksi Kas Mutasi","Edit");
INSERT INTO `akses`  VALUES ( "324","Accounting","Retur","Lihat");
INSERT INTO `akses`  VALUES ( "325","Accounting","Retur Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "326","Accounting","Retur Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "327","Accounting","Retur Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "328","Accounting","Retur Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "329","Accounting","Kas","Lihat");
INSERT INTO `akses`  VALUES ( "330","Accounting","Kas","Tambah");
INSERT INTO `akses`  VALUES ( "331","Accounting","Kas","Hapus");
INSERT INTO `akses`  VALUES ( "332","Accounting","Kas","Edit");
INSERT INTO `akses`  VALUES ( "333","Accounting","Posisi Kas","Lihat");
INSERT INTO `akses`  VALUES ( "334","Accounting","Posisi Kas","Tambah");
INSERT INTO `akses`  VALUES ( "335","Accounting","Posisi Kas","Hapus");
INSERT INTO `akses`  VALUES ( "336","Accounting","Posisi Kas","Edit");
INSERT INTO `akses`  VALUES ( "337","Accounting","Laporan","Lihat");
INSERT INTO `akses`  VALUES ( "338","Accounting","Laporan Komisi Produk","Lihat");
INSERT INTO `akses`  VALUES ( "339","Accounting","Laporan Komisi Produk","Tambah");
INSERT INTO `akses`  VALUES ( "340","Accounting","Laporan Komisi Produk","Hapus");
INSERT INTO `akses`  VALUES ( "341","Accounting","Laporan Komisi Produk","Edit");
INSERT INTO `akses`  VALUES ( "342","Accounting","Laporan Komisi Faktur","Lihat");
INSERT INTO `akses`  VALUES ( "343","Accounting","Laporan Komisi Faktur","Tambah");
INSERT INTO `akses`  VALUES ( "344","Accounting","Laporan Komisi Faktur","Hapus");
INSERT INTO `akses`  VALUES ( "345","Accounting","Laporan Komisi Faktur","Edit");
INSERT INTO `akses`  VALUES ( "346","Accounting","Laporan Komisi","Lihat");
INSERT INTO `akses`  VALUES ( "347","Accounting","Laporan Komisi","Tambah");
INSERT INTO `akses`  VALUES ( "348","Accounting","Laporan Komisi","Hapus");
INSERT INTO `akses`  VALUES ( "349","Accounting","Laporan Komisi","Edit");
INSERT INTO `akses`  VALUES ( "350","Accounting","Laporan Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "351","Accounting","Laporan Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "352","Accounting","Laporan Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "353","Accounting","Laporan Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "354","Accounting","Laporan Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "355","Accounting","Laporan Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "356","Accounting","Laporan Penjualan","Hapus");
INSERT INTO `akses`  VALUES ( "357","Accounting","Laporan Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "358","Accounting","Laporan Retur Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "359","Accounting","Laporan Retur Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "360","Accounting","Laporan Retur Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "361","Accounting","Laporan Retur Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "362","Accounting","Laporan Retur Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "363","Accounting","Laporan Retur Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "364","Accounting","Laporan Retur Penjualan","Hapus");
INSERT INTO `akses`  VALUES ( "365","Accounting","Laporan Retur Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "366","Accounting","Laporan Pembayaran Hutang","Lihat");
INSERT INTO `akses`  VALUES ( "367","Accounting","Laporan Pembayaran Hutang","Tambah");
INSERT INTO `akses`  VALUES ( "368","Accounting","Laporan Pembayaran Hutang","Hapus");
INSERT INTO `akses`  VALUES ( "369","Accounting","Laporan Pembayaran Hutang","Edit");
INSERT INTO `akses`  VALUES ( "370","Accounting","Laporan Pembayaran Piutang","Lihat");
INSERT INTO `akses`  VALUES ( "371","Accounting","Laporan Pembayaran Piutang","Tambah");
INSERT INTO `akses`  VALUES ( "372","Accounting","Laporan Pembayaran Piutang","Hapus");
INSERT INTO `akses`  VALUES ( "373","Accounting","Laporan Pembayaran Piutang","Edit");
INSERT INTO `akses`  VALUES ( "374","Purchasing","Master Data","Lihat");
INSERT INTO `akses`  VALUES ( "399","Purchasing","Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "400","Purchasing","Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "401","Purchasing","Persediaan Item Masuk","Lihat");
INSERT INTO `akses`  VALUES ( "402","Purchasing","Persediaan Item Masuk","Tambah");
INSERT INTO `akses`  VALUES ( "403","Purchasing","Persediaan Item Keluar","Lihat");
INSERT INTO `akses`  VALUES ( "404","Purchasing","Persediaan Item Keluar","Tambah");
INSERT INTO `akses`  VALUES ( "405","Purchasing","Persediaan Item","Lihat");
INSERT INTO `akses`  VALUES ( "406","Purchasing","Persediaan Item","Tambah");
INSERT INTO `akses`  VALUES ( "407","Accounting","Laporan Cash FLow Per Tanggal","Lihat");
INSERT INTO `akses`  VALUES ( "408","Accounting","Laporan Cash FLow Per Periode","Lihat");
INSERT INTO `akses`  VALUES ( "411","Pimpinan","Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "412","Pimpinan","Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "413","Pimpinan","Penjualan","Hapus");
INSERT INTO `akses`  VALUES ( "414","Pimpinan","Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "415","Pimpinan","Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "416","Pimpinan","Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "417","Pimpinan","Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "418","Pimpinan","Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "419","Pimpinan","User","Lihat");
INSERT INTO `akses`  VALUES ( "420","Pimpinan","User","Tambah");
INSERT INTO `akses`  VALUES ( "421","Pimpinan","User","Hapus");
INSERT INTO `akses`  VALUES ( "422","Pimpinan","User","Edit");
INSERT INTO `akses`  VALUES ( "423","Pimpinan","Satuan","Lihat");
INSERT INTO `akses`  VALUES ( "424","Pimpinan","Satuan","Tambah");
INSERT INTO `akses`  VALUES ( "425","Pimpinan","Satuan","Hapus");
INSERT INTO `akses`  VALUES ( "426","Pimpinan","Satuan","Edit");
INSERT INTO `akses`  VALUES ( "427","Pimpinan","Jabatan","Lihat");
INSERT INTO `akses`  VALUES ( "428","Pimpinan","Jabatan","Tambah");
INSERT INTO `akses`  VALUES ( "429","Pimpinan","Jabatan","Hapus");
INSERT INTO `akses`  VALUES ( "430","Pimpinan","Jabatan","Edit");
INSERT INTO `akses`  VALUES ( "431","Pimpinan","Pelanggan","Lihat");
INSERT INTO `akses`  VALUES ( "432","Pimpinan","Pelanggan","Tambah");
INSERT INTO `akses`  VALUES ( "433","Pimpinan","Pelanggan","Hapus");
INSERT INTO `akses`  VALUES ( "434","Pimpinan","Pelanggan","Edit");
INSERT INTO `akses`  VALUES ( "435","Pimpinan","Suplier","Lihat");
INSERT INTO `akses`  VALUES ( "436","Pimpinan","Suplier","Tambah");
INSERT INTO `akses`  VALUES ( "437","Pimpinan","Suplier","Hapus");
INSERT INTO `akses`  VALUES ( "438","Pimpinan","Suplier","Edit");
INSERT INTO `akses`  VALUES ( "439","Pimpinan","Item","Lihat");
INSERT INTO `akses`  VALUES ( "440","Pimpinan","Item","Tambah");
INSERT INTO `akses`  VALUES ( "441","Pimpinan","Item","Hapus");
INSERT INTO `akses`  VALUES ( "442","Pimpinan","Item","Edit");
INSERT INTO `akses`  VALUES ( "443","Pimpinan","Pemasukan","Lihat");
INSERT INTO `akses`  VALUES ( "444","Pimpinan","Pemasukan","Tambah");
INSERT INTO `akses`  VALUES ( "445","Pimpinan","Pemasukan","Hapus");
INSERT INTO `akses`  VALUES ( "446","Pimpinan","Pemasukan","Edit");
INSERT INTO `akses`  VALUES ( "447","Pimpinan","Pengeluaran","Lihat");
INSERT INTO `akses`  VALUES ( "448","Pimpinan","Pengeluaran","Tambah");
INSERT INTO `akses`  VALUES ( "449","Pimpinan","Pengeluaran","Hapus");
INSERT INTO `akses`  VALUES ( "450","Pimpinan","Pengeluaran","Edit");
INSERT INTO `akses`  VALUES ( "451","Pimpinan","Meja","Lihat");
INSERT INTO `akses`  VALUES ( "452","Pimpinan","Meja","Tambah");
INSERT INTO `akses`  VALUES ( "453","Pimpinan","Meja","Hapus");
INSERT INTO `akses`  VALUES ( "454","Pimpinan","Meja","Edit");
INSERT INTO `akses`  VALUES ( "455","Pimpinan","Komisi Produk","Lihat");
INSERT INTO `akses`  VALUES ( "456","Pimpinan","Komisi Produk","Tambah");
INSERT INTO `akses`  VALUES ( "457","Pimpinan","Komisi Produk","Hapus");
INSERT INTO `akses`  VALUES ( "458","Pimpinan","Komisi Produk","Edit");
INSERT INTO `akses`  VALUES ( "459","Pimpinan","Komisi Faktur","Lihat");
INSERT INTO `akses`  VALUES ( "460","Pimpinan","Komisi Faktur","Tambah");
INSERT INTO `akses`  VALUES ( "461","Pimpinan","Komisi Faktur","Hapus");
INSERT INTO `akses`  VALUES ( "462","Pimpinan","Komisi Faktur","Edit");
INSERT INTO `akses`  VALUES ( "463","Pimpinan","Data Perusahaan","Lihat");
INSERT INTO `akses`  VALUES ( "464","Pimpinan","Data Perusahaan","Tambah");
INSERT INTO `akses`  VALUES ( "465","Pimpinan","Data Perusahaan","Hapus");
INSERT INTO `akses`  VALUES ( "466","Pimpinan","Data Perusahaan","Edit");
INSERT INTO `akses`  VALUES ( "467","Pimpinan","Default Diskon - Pajak","Lihat");
INSERT INTO `akses`  VALUES ( "468","Pimpinan","Default Diskon - Pajak","Tambah");
INSERT INTO `akses`  VALUES ( "469","Pimpinan","Default Diskon - Pajak","Hapus");
INSERT INTO `akses`  VALUES ( "470","Pimpinan","Default Diskon - Pajak","Edit");
INSERT INTO `akses`  VALUES ( "471","Pimpinan","Hak Otoritas","Lihat");
INSERT INTO `akses`  VALUES ( "472","Pimpinan","Hak Otoritas","Tambah");
INSERT INTO `akses`  VALUES ( "473","Pimpinan","Hak Otoritas","Hapus");
INSERT INTO `akses`  VALUES ( "474","Pimpinan","Hak Otoritas","Edit");
INSERT INTO `akses`  VALUES ( "475","Pimpinan","Pembayaran","Lihat");
INSERT INTO `akses`  VALUES ( "476","Pimpinan","Pembayaran","Tambah");
INSERT INTO `akses`  VALUES ( "477","Pimpinan","Pembayaran","Hapus");
INSERT INTO `akses`  VALUES ( "478","Pimpinan","Pembayaran","Edit");
INSERT INTO `akses`  VALUES ( "479","Pimpinan","Pembayaran Hutang","Lihat");
INSERT INTO `akses`  VALUES ( "480","Pimpinan","Pembayaran Hutang","Tambah");
INSERT INTO `akses`  VALUES ( "481","Pimpinan","Pembayaran Hutang","Hapus");
INSERT INTO `akses`  VALUES ( "482","Pimpinan","Pembayaran Hutang","Edit");
INSERT INTO `akses`  VALUES ( "483","Pimpinan","Pembayaran Piutang","Lihat");
INSERT INTO `akses`  VALUES ( "484","Pimpinan","Pembayaran Piutang","Tambah");
INSERT INTO `akses`  VALUES ( "485","Pimpinan","Pembayaran Piutang","Hapus");
INSERT INTO `akses`  VALUES ( "486","Pimpinan","Pembayaran Piutang","Edit");
INSERT INTO `akses`  VALUES ( "487","Pimpinan","Transaksi Kas","Lihat");
INSERT INTO `akses`  VALUES ( "488","Pimpinan","Transaksi Kas","Tambah");
INSERT INTO `akses`  VALUES ( "489","Pimpinan","Transaksi Kas","Hapus");
INSERT INTO `akses`  VALUES ( "490","Pimpinan","Transaksi Kas","Edit");
INSERT INTO `akses`  VALUES ( "491","Pimpinan","Transaksi Kas Masuk","Lihat");
INSERT INTO `akses`  VALUES ( "492","Pimpinan","Transaksi Kas Masuk","Tambah");
INSERT INTO `akses`  VALUES ( "493","Pimpinan","Transaksi Kas Masuk","Hapus");
INSERT INTO `akses`  VALUES ( "494","Pimpinan","Transaksi Kas Masuk","Edit");
INSERT INTO `akses`  VALUES ( "495","Pimpinan","Transaksi Kas Keluar","Lihat");
INSERT INTO `akses`  VALUES ( "496","Pimpinan","Transaksi Kas Keluar","Tambah");
INSERT INTO `akses`  VALUES ( "497","Pimpinan","Transaksi Kas Keluar","Hapus");
INSERT INTO `akses`  VALUES ( "498","Pimpinan","Transaksi Kas Keluar","Edit");
INSERT INTO `akses`  VALUES ( "499","Pimpinan","Transaksi Kas Mutasi","Lihat");
INSERT INTO `akses`  VALUES ( "500","Pimpinan","Transaksi Kas Mutasi","Tambah");
INSERT INTO `akses`  VALUES ( "501","Pimpinan","Transaksi Kas Mutasi","Hapus");
INSERT INTO `akses`  VALUES ( "502","Pimpinan","Transaksi Kas Mutasi","Edit");
INSERT INTO `akses`  VALUES ( "503","Pimpinan","Persediaan","Lihat");
INSERT INTO `akses`  VALUES ( "504","Pimpinan","Persediaan","Tambah");
INSERT INTO `akses`  VALUES ( "505","Pimpinan","Persediaan","Hapus");
INSERT INTO `akses`  VALUES ( "506","Pimpinan","Persediaan","Edit");
INSERT INTO `akses`  VALUES ( "507","Pimpinan","Persediaan Stok Awal","Lihat");
INSERT INTO `akses`  VALUES ( "508","Pimpinan","Persediaan Stok Awal","Tambah");
INSERT INTO `akses`  VALUES ( "509","Pimpinan","Persediaan Stok Awal","Hapus");
INSERT INTO `akses`  VALUES ( "510","Pimpinan","Persediaan Stok Awal","Edit");
INSERT INTO `akses`  VALUES ( "511","Pimpinan","Persediaan Stok Opname","Lihat");
INSERT INTO `akses`  VALUES ( "512","Pimpinan","Persediaan Stok Opname","Tambah");
INSERT INTO `akses`  VALUES ( "513","Pimpinan","Persediaan Stok Opname","Hapus");
INSERT INTO `akses`  VALUES ( "514","Pimpinan","Persediaan Stok Opname","Edit");
INSERT INTO `akses`  VALUES ( "515","Pimpinan","Persediaan Item","Lihat");
INSERT INTO `akses`  VALUES ( "516","Pimpinan","Persediaan Item","Tambah");
INSERT INTO `akses`  VALUES ( "517","Pimpinan","Persediaan Item","Hapus");
INSERT INTO `akses`  VALUES ( "518","Pimpinan","Persediaan Item","Edit");
INSERT INTO `akses`  VALUES ( "519","Pimpinan","Persediaan Item Masuk","Lihat");
INSERT INTO `akses`  VALUES ( "520","Pimpinan","Persediaan Item Masuk","Tambah");
INSERT INTO `akses`  VALUES ( "521","Pimpinan","Persediaan Item Masuk","Hapus");
INSERT INTO `akses`  VALUES ( "522","Pimpinan","Persediaan Item Masuk","Edit");
INSERT INTO `akses`  VALUES ( "523","Pimpinan","Persediaan Item Keluar","Lihat");
INSERT INTO `akses`  VALUES ( "524","Pimpinan","Persediaan Item Keluar","Tambah");
INSERT INTO `akses`  VALUES ( "525","Pimpinan","Persediaan Item Keluar","Hapus");
INSERT INTO `akses`  VALUES ( "526","Pimpinan","Persediaan Item Keluar","Edit");
INSERT INTO `akses`  VALUES ( "527","Pimpinan","Retur","Lihat");
INSERT INTO `akses`  VALUES ( "528","Pimpinan","Retur","Tambah");
INSERT INTO `akses`  VALUES ( "529","Pimpinan","Retur","Hapus");
INSERT INTO `akses`  VALUES ( "530","Pimpinan","Retur","Edit");
INSERT INTO `akses`  VALUES ( "531","Pimpinan","Retur Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "532","Pimpinan","Retur Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "533","Pimpinan","Retur Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "534","Pimpinan","Retur Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "535","Pimpinan","Retur Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "536","Pimpinan","Retur Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "537","Pimpinan","Retur Penjualan","Hapus");
INSERT INTO `akses`  VALUES ( "538","Pimpinan","Retur Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "539","Pimpinan","Kas","Lihat");
INSERT INTO `akses`  VALUES ( "540","Pimpinan","Kas","Tambah");
INSERT INTO `akses`  VALUES ( "541","Pimpinan","Kas","Hapus");
INSERT INTO `akses`  VALUES ( "542","Pimpinan","Kas","Edit");
INSERT INTO `akses`  VALUES ( "543","Pimpinan","Posisi Kas","Lihat");
INSERT INTO `akses`  VALUES ( "544","Pimpinan","Posisi Kas","Tambah");
INSERT INTO `akses`  VALUES ( "545","Pimpinan","Posisi Kas","Hapus");
INSERT INTO `akses`  VALUES ( "546","Pimpinan","Posisi Kas","Edit");
INSERT INTO `akses`  VALUES ( "547","Pimpinan","Laporan","Lihat");
INSERT INTO `akses`  VALUES ( "548","Pimpinan","Laporan","Tambah");
INSERT INTO `akses`  VALUES ( "549","Pimpinan","Laporan","Hapus");
INSERT INTO `akses`  VALUES ( "550","Pimpinan","Laporan","Edit");
INSERT INTO `akses`  VALUES ( "551","Pimpinan","Laporan Cash FLow Per Tanggal","Lihat");
INSERT INTO `akses`  VALUES ( "552","Pimpinan","Laporan Cash FLow Per Tanggal","Tambah");
INSERT INTO `akses`  VALUES ( "553","Pimpinan","Laporan Cash FLow Per Tanggal","Hapus");
INSERT INTO `akses`  VALUES ( "554","Pimpinan","Laporan Cash FLow Per Tanggal","Edit");
INSERT INTO `akses`  VALUES ( "555","Pimpinan","Laporan Cash FLow Per Periode","Lihat");
INSERT INTO `akses`  VALUES ( "556","Pimpinan","Laporan Cash FLow Per Periode","Tambah");
INSERT INTO `akses`  VALUES ( "557","Pimpinan","Laporan Cash FLow Per Periode","Hapus");
INSERT INTO `akses`  VALUES ( "558","Pimpinan","Laporan Cash FLow Per Periode","Edit");
INSERT INTO `akses`  VALUES ( "559","Pimpinan","Laporan Komisi Produk","Lihat");
INSERT INTO `akses`  VALUES ( "560","Pimpinan","Laporan Komisi Produk","Tambah");
INSERT INTO `akses`  VALUES ( "561","Pimpinan","Laporan Komisi Produk","Hapus");
INSERT INTO `akses`  VALUES ( "562","Pimpinan","Laporan Komisi Produk","Edit");
INSERT INTO `akses`  VALUES ( "563","Pimpinan","Laporan Komisi Faktur","Lihat");
INSERT INTO `akses`  VALUES ( "564","Pimpinan","Laporan Komisi Faktur","Tambah");
INSERT INTO `akses`  VALUES ( "565","Pimpinan","Laporan Komisi Faktur","Hapus");
INSERT INTO `akses`  VALUES ( "566","Pimpinan","Laporan Komisi Faktur","Edit");
INSERT INTO `akses`  VALUES ( "567","Pimpinan","Laporan Komisi","Lihat");
INSERT INTO `akses`  VALUES ( "568","Pimpinan","Laporan Komisi","Tambah");
INSERT INTO `akses`  VALUES ( "569","Pimpinan","Laporan Komisi","Hapus");
INSERT INTO `akses`  VALUES ( "570","Pimpinan","Laporan Komisi","Edit");
INSERT INTO `akses`  VALUES ( "571","Pimpinan","Laporan Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "572","Pimpinan","Laporan Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "573","Pimpinan","Laporan Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "574","Pimpinan","Laporan Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "575","Pimpinan","Laporan Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "576","Pimpinan","Laporan Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "577","Pimpinan","Laporan Penjualan","Hapus");
INSERT INTO `akses`  VALUES ( "578","Pimpinan","Laporan Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "579","Pimpinan","Laporan Retur Pembelian","Lihat");
INSERT INTO `akses`  VALUES ( "580","Pimpinan","Laporan Retur Pembelian","Tambah");
INSERT INTO `akses`  VALUES ( "581","Pimpinan","Laporan Retur Pembelian","Hapus");
INSERT INTO `akses`  VALUES ( "582","Pimpinan","Laporan Retur Pembelian","Edit");
INSERT INTO `akses`  VALUES ( "583","Pimpinan","Laporan Retur Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "584","Pimpinan","Laporan Retur Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "585","Pimpinan","Laporan Retur Penjualan","Hapus");
INSERT INTO `akses`  VALUES ( "586","Pimpinan","Laporan Retur Penjualan","Edit");
INSERT INTO `akses`  VALUES ( "587","Pimpinan","Laporan Pembayaran Hutang","Lihat");
INSERT INTO `akses`  VALUES ( "588","Pimpinan","Laporan Pembayaran Hutang","Tambah");
INSERT INTO `akses`  VALUES ( "589","Pimpinan","Laporan Pembayaran Hutang","Hapus");
INSERT INTO `akses`  VALUES ( "590","Pimpinan","Laporan Pembayaran Hutang","Edit");
INSERT INTO `akses`  VALUES ( "591","Pimpinan","Laporan Pembayaran Piutang","Lihat");
INSERT INTO `akses`  VALUES ( "592","Pimpinan","Laporan Pembayaran Piutang","Tambah");
INSERT INTO `akses`  VALUES ( "593","Pimpinan","Laporan Pembayaran Piutang","Hapus");
INSERT INTO `akses`  VALUES ( "594","Pimpinan","Laporan Pembayaran Piutang","Edit");
INSERT INTO `akses`  VALUES ( "595","Pimpinan","Master Data","Lihat");
INSERT INTO `akses`  VALUES ( "596","Pimpinan","Master Data","Tambah");
INSERT INTO `akses`  VALUES ( "597","Pimpinan","Master Data","Hapus");
INSERT INTO `akses`  VALUES ( "598","Pimpinan","Master Data","Edit");
INSERT INTO `akses`  VALUES ( "602","Cashier","Penjualan","Tambah");
INSERT INTO `akses`  VALUES ( "603","Cashier","Penjualan","Lihat");
INSERT INTO `akses`  VALUES ( "604","Pimpinan","Daftar Group Akun","Lihat");
INSERT INTO `akses`  VALUES ( "605","Pimpinan","Daftar Group Akun","Tambah");
INSERT INTO `akses`  VALUES ( "606","Pimpinan","Daftar Group Akun","Hapus");
INSERT INTO `akses`  VALUES ( "607","Pimpinan","Daftar Group Akun","Edit");
INSERT INTO `akses`  VALUES ( "608","Pimpinan","Daftar Akun","Lihat");
INSERT INTO `akses`  VALUES ( "609","Pimpinan","Daftar Akun","Tambah");
INSERT INTO `akses`  VALUES ( "610","Pimpinan","Daftar Akun","Hapus");
INSERT INTO `akses`  VALUES ( "611","Pimpinan","Daftar Akun","Edit");
INSERT INTO `akses`  VALUES ( "612","Pimpinan","Laporan Pemasukan Rekap","Lihat");
INSERT INTO `akses`  VALUES ( "613","Pimpinan","Laporan Pemasukan Rekap","Tambah");
INSERT INTO `akses`  VALUES ( "614","Pimpinan","Laporan Pemasukan Rekap","Hapus");
INSERT INTO `akses`  VALUES ( "615","Pimpinan","Laporan Pemasukan Rekap","Edit");
INSERT INTO `akses`  VALUES ( "616","Pimpinan","Laporan Pemasukan Pertanggal","Lihat");
INSERT INTO `akses`  VALUES ( "617","Pimpinan","Laporan Pemasukan Perperiode","Lihat");
INSERT INTO `akses`  VALUES ( "618","Pimpinan","Laporan Pengeluaran Rekap","Lihat");
INSERT INTO `akses`  VALUES ( "619","Pimpinan","Laporan Pengeluaran Pertanggal","Lihat");
INSERT INTO `akses`  VALUES ( "620","Pimpinan","Laporan Pengeluaran Perperiode","Lihat");
INSERT INTO `akses`  VALUES ( "621","Pimpinan","Laporan Hutang Beredar","Lihat");
INSERT INTO `akses`  VALUES ( "622","Pimpinan","Laporan Piutang Beredar","Lihat");
INSERT INTO `akses`  VALUES ( "623","Pimpinan","Transaksi Jurnal Manual","Lihat");
INSERT INTO `akses`  VALUES ( "624","Pimpinan","Laporan Jurnal","Lihat");
INSERT INTO `akses`  VALUES ( "625","Pimpinan","Buku Besar","Lihat");
INSERT INTO `akses`  VALUES ( "626","Pimpinan","Transaksi Jurnal Manual","Tambah");
INSERT INTO `akses`  VALUES ( "627","Pimpinan","Transaksi Jurnal Manual","Hapus");
INSERT INTO `akses`  VALUES ( "628","Pimpinan","Transaksi Jurnal Manual","Edit");


--
-- Tabel structure for table `barang`
--
DROP TABLE  IF EXISTS `barang`;
CREATE TABLE `barang` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_beli` int(25) NOT NULL,
  `harga_jual` int(25) NOT NULL,
  `harga_jual2` int(100) NOT NULL,
  `harga_jual3` int(100) NOT NULL,
  `stok_barang` int(25) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `gudang` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `suplier` varchar(50) NOT NULL,
  `stok_awal` varchar(100) NOT NULL,
  `stok_opname` varchar(100) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `limit_stok` int(100) NOT NULL,
  `over_stok` int(100) NOT NULL,
  `berkaitan_dgn_stok` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=latin1;

INSERT INTO `barang`  VALUES ( "145","BJ1","CERIA CITRA 150ML","0","12500","11500","10500","0","PCS","BARANG JADI","Gudang B","Aktif","PT. DHARMA GUNA","","","","10","0","Barang");
INSERT INTO `barang`  VALUES ( "146","BJ2","CERIA CITRA 240ML","1000","14500","13750","13000","0","PCS","BARANG JADI","Gudang A","Aktif","PT. DHARMA GUNA","","","","0","1000000","Barang");
INSERT INTO `barang`  VALUES ( "147","BJ3","CERIA CITRA 330ML","0","25000","24500","23000","0","PCS","BARANG JADI","Gudang A","Aktif","PT. DHARMA GUNA","","","","0","1000000","Barang");
INSERT INTO `barang`  VALUES ( "148","BJ4","CERIA CITRA 600ML","400","25000","24000","23000","0","PCS","BARANG JADI","Gudang A","Aktif","PT. DHARMA GUNA","","","","0","1000000","Barang");
INSERT INTO `barang`  VALUES ( "149","BJ5","CERIA CITRA 1500ML","0","25000","24000","23000","0","PCS","BARANG JADI","Gudang A","Aktif","PT. DHARMA GUNA","","","","0","1000000","Barang");
INSERT INTO `barang`  VALUES ( "150","BJ6","CERIA CITRA 19L","0","7000","6500","6000","0","PCS","BARANG JADI","Gudang A","Aktif","PT. DHARMA GUNA","","","","0","1000000","Barang");
INSERT INTO `barang`  VALUES ( "151","BJ7","CERIA CITRA AIR TANGKI 6000L","0","175000","150000","125000","0","PCS","BARANG JADI","Gudang A","Aktif","PT. DHARMA GUNA","","","","0","0","Jasa");
INSERT INTO `barang`  VALUES ( "152","BB1","CUP 240ML DELTAPACK","150","1000","0","0","0","PCS","BAHAN BAKU","","Aktif","Deltapack","","","","75000","1000000","Barang");
INSERT INTO `barang`  VALUES ( "153","BB2","CUP 240ML GKI","98","100","102","110","0","PCS","BAHAN BAKU","","Aktif","PT GUNA KEMAS INDAH","ada","","","225000","1000000","Barang");
INSERT INTO `barang`  VALUES ( "154","BB3","CUP 240ML ARGA","94","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","Saranabaja Ragam Citra","","","","225000","1000000","Barang");
INSERT INTO `barang`  VALUES ( "155","BB4","CUP 150ML DELTAPACK","102","0","0","0","0","PCS","BAHAN BAKU","","Aktif","Deltapack","","","","225000","1000000","Barang");
INSERT INTO `barang`  VALUES ( "156","BB5","CUP 150ML ARGA","94","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","Saranabaja Ragam Citra","","","","165000","1000000","Barang");
INSERT INTO `barang`  VALUES ( "157","BB6","STRAW","11","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","PT. Multi Sejahtera Platisindo","","","","150336","2000000","Barang");
INSERT INTO `barang`  VALUES ( "158","BB7","LID 4 LINE","28","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","Sarana Mitra Kemas","","","","777600","2937600","Barang");
INSERT INTO `barang`  VALUES ( "159","BB8","LID 8 LINE","28","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","Sarana Mitra Kemas","","","","518400","4838400","Barang");
INSERT INTO `barang`  VALUES ( "160","BB9","KARDUS 240ML","2850","0","0","0","0","PCS","BAHAN BAKU","","Aktif","CV. Karindo","","","","6000","50000","Barang");
INSERT INTO `barang`  VALUES ( "161","BB10","KARDUS 240ML","5000","1000","0","0","0","PCS","BAHAN BAKU","","Aktif","Konverta Mitra Abadi","","","","3000","20000","Barang");
INSERT INTO `barang`  VALUES ( "162","BB11","KARDUS 150ML","2100","0","0","0","0","PCS","BAHAN BAKU","","Aktif","CV. Karindo","ada","","","2250","20000","Barang");
INSERT INTO `barang`  VALUES ( "163","BB12","BOTOL 330ML","400","0","0","0","0","PCS","BAHAN BAKU","","Aktif","PT. NUsantara Prima Lestari","ada","","","150","5000","Barang");
INSERT INTO `barang`  VALUES ( "164","BB13","LABEL BOTOL 330ML","48","0","0","0","0","PCS","BAHAN BAKU","","Aktif","Sarana Mitra Kemas","","","","5000","100000","Barang");
INSERT INTO `barang`  VALUES ( "165","BB14","KARDUS 330ML","2350","0","0","0","0","PCS","BAHAN BAKU","","Aktif","Konverta Mitra Abadi","ada","","","500","10000","Barang");
INSERT INTO `barang`  VALUES ( "166","BB15","BOTOL 600ML","410","0","0","0","0","PCS","BAHAN BAKU","","Aktif","PT. Namasindo","ada","","","1000","20000","Barang");
INSERT INTO `barang`  VALUES ( "167","BB16","LABEL BOTOL 600ML","56","0","0","0","0","PCS","BAHAN BAKU","","Aktif","Sarana Mitra Kemas","","","","5000","200000","Barang");
INSERT INTO `barang`  VALUES ( "168","BB17","KARDUS 600ML","3300","0","0","0","0","PCS","BAHAN BAKU","","Aktif","Konverta Mitra Abadi","","","","500","20000","Barang");
INSERT INTO `barang`  VALUES ( "169","BB18","BOTOL 1500ML","750","0","0","0","0","PCS","BAHAN BAKU","","Aktif","PT. Namasindo","","","","500","10000","Barang");
INSERT INTO `barang`  VALUES ( "170","BB19","LABEL BOTOL 1500ML","71","0","0","0","0","PCS","BAHAN BAKU","","Aktif","Sarana Mitra Kemas","","","","1000","100000","Barang");
INSERT INTO `barang`  VALUES ( "171","BB20","KARDUS 1500ML","3500","0","0","0","0","PCS","BAHAN BAKU","Gudang C","Aktif","Konverta Mitra Abadi","","","","1","10000","Barang");
INSERT INTO `barang`  VALUES ( "172","BB21","LAKBAN","6500","7000","0","0","0","PCS","BAHAN BAKU","Gudang B","Aktif","Umum","","","","1","750","Barang");
INSERT INTO `barang`  VALUES ( "173","BB22","CAPSEAL","16","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","Sarana Mitra Kemas","","","","1","200000","Barang");
INSERT INTO `barang`  VALUES ( "174","BB23","TUTUP BOTOL","70","0","0","0","0","PCS","BAHAN BAKU","Gudang C","Aktif","PT. Namasindo","","","","1","30000","Barang");
INSERT INTO `barang`  VALUES ( "175","BB24","LABEL GALON","1000","0","0","0","0","PCS","BAHAN BAKU","Gudang B","Aktif","Sarana Mitra Kemas","","","","1","10000","Barang");
INSERT INTO `barang`  VALUES ( "176","BB25","TUTUP GALON HIJAU","335","0","0","0","0","PCS","BAHAN BAKU","Gudang B","Aktif","PT. Namasindo","","","","1","20000","Barang");
INSERT INTO `barang`  VALUES ( "177","BB26","TUTUP GALON BIRU","325","0","0","0","0","PCS","BAHAN BAKU","","Aktif","PT. Namasindo","","","","0","30000","Barang");
INSERT INTO `barang`  VALUES ( "178","BB27","CAPSEAL GALON","71","0","0","0","0","PCS","BAHAN BAKU","Gudang A","Aktif","Sarana Mitra Kemas","","","","1","30000","Barang");
INSERT INTO `barang`  VALUES ( "179","BB28","TISSUE GALON","75","0","0","0","0","PCS","BAHAN BAKU","Gudang B","Aktif","Umum","","","","10","0","Barang");
INSERT INTO `barang`  VALUES ( "185","BB29","GALON CERIA ","32000","25000","27000","33000","0","PCS","BAHAN BAKU","GD001","Aktif","PT. Namasindo","","","","20","20000","Barang");
INSERT INTO `barang`  VALUES ( "186","BB30","AIR GALON CERIA","1700","6500","7000","8000","0","GALON","BAHAN BAKU","GD001","Aktif","Umum","","","","0","20000","Barang");
INSERT INTO `barang`  VALUES ( "187","BB31","KARDUS 240","15000","20000","200","300","0","PCS","BAHAN BAKU","GD001","Aktif","PT ULTRA PRIMA","ada","","","5000","100000","Barang");
INSERT INTO `barang`  VALUES ( "188","BB32","LAYER","250","30000","275","300","0","PCS","BAHAN BAKU","GD001","Aktif","Umum","","","","2000","30000","Barang");


--
-- Tabel structure for table `batal_detail_penjualan`
--
DROP TABLE  IF EXISTS `batal_detail_penjualan`;
CREATE TABLE `batal_detail_penjualan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `kode_meja` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah_barang` int(100) NOT NULL,
  `satuan` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  `status` int(100) NOT NULL,
  `hpp` int(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  `no_pesanan` int(10) NOT NULL,
  `komentar` varchar(100) NOT NULL,
  `batal_detail_penjualan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `batal_penjualan`
--
DROP TABLE  IF EXISTS `batal_penjualan`;
CREATE TABLE `batal_penjualan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `kode_pelanggan` varchar(100) NOT NULL,
  `kode_meja` varchar(100) NOT NULL,
  `total` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  `kredit` int(100) NOT NULL,
  `total_hpp` int(100) NOT NULL,
  `cara_bayar` varchar(100) NOT NULL,
  `tunai` int(100) NOT NULL,
  `no_pesanan` int(10) NOT NULL,
  `keterangan_batal` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `daftar_akun`
--
DROP TABLE  IF EXISTS `daftar_akun`;
CREATE TABLE `daftar_akun` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kode_daftar_akun` varchar(100) NOT NULL,
  `nama_daftar_akun` varchar(100) NOT NULL,
  `grup_akun` varchar(100) NOT NULL,
  `kategori_akun` varchar(100) NOT NULL,
  `tipe_akun` varchar(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `daftar_akun`  VALUES ( "2","K/001","Kas","KA/001","Aset","Kas & Bank","Team 3","Team 3","2016-07-02 13:25:53");
INSERT INTO `daftar_akun`  VALUES ( "3","K/002","Persediaan","KA/002","Aset","Persediaan","Team 3","Team 3","2016-07-02 13:26:21");
INSERT INTO `daftar_akun`  VALUES ( "4","K/003","Pajak","KA/004","Biaya","Hutang Pajak","Team 3","Team 3","2016-07-02 13:27:59");
INSERT INTO `daftar_akun`  VALUES ( "5","K/004","Hutang","KA/003","Laibilitas","Hutang Dagang","Team 3","Team 3","2016-07-02 13:34:32");
INSERT INTO `daftar_akun`  VALUES ( "6","K/005","Modal","KA/001","Aset","Kas & Bank","Team 3","","2016-07-02 13:35:16");
INSERT INTO `daftar_akun`  VALUES ( "8","K/006","Item Masuk","KA/002","Aset","Persediaan","Team 3","","2016-07-02 16:00:45");
INSERT INTO `daftar_akun`  VALUES ( "9","K/007","Item Keluar","KA/002","Aset","Persediaan","Team 3","","2016-07-04 15:20:16");
INSERT INTO `daftar_akun`  VALUES ( "10","K/008","Retur Penjualan","KA/002","Aset","Persediaan","Team 3","","2016-07-04 16:02:23");
INSERT INTO `daftar_akun`  VALUES ( "11","K/009","Retur Pembelian","KA/002","Aset","Persediaan","Team 3","","2016-07-04 16:04:49");
INSERT INTO `daftar_akun`  VALUES ( "12","K/010","Potongan Penjualan","KA/009","Biaya","Kas & Bank","Team 3","","2016-07-05 09:13:24");
INSERT INTO `daftar_akun`  VALUES ( "13","K/011","Pajak Penjualan","KA/010","Biaya","Beban Pajak Penghasilan","Team 3","Team 3","2016-07-05 09:14:26");
INSERT INTO `daftar_akun`  VALUES ( "14","K/012","Komisi Sales","KA/011","Laibilitas","Beban Administrasi dan Umum","Team 3","","2016-07-05 09:15:31");
INSERT INTO `daftar_akun`  VALUES ( "15","K/013","Piutang","KA/013","Pendapatan","Kas & Bank","Team 3","Team 3","2016-07-05 09:17:06");
INSERT INTO `daftar_akun`  VALUES ( "16","K/014","Total Penjualan","KA/012","Pendapatan","Kas & Bank","Team 3","","2016-07-05 09:17:51");
INSERT INTO `daftar_akun`  VALUES ( "17","K/015","Hpp Penjualan","KA/002","Pendapatan","Harga Pokok Penjualan","Team 3","Team 3","2016-07-05 09:32:31");
INSERT INTO `daftar_akun`  VALUES ( "18","K/016","Stok Awal","KA/002","Ekuitas","Ekuitas","Team 3","","2016-08-08 14:00:34");
INSERT INTO `daftar_akun`  VALUES ( "19","K/017","Stok Opname","KA/002","Biaya","Harga Pokok Penjualan","Team 3","","2016-08-08 16:49:27");
INSERT INTO `daftar_akun`  VALUES ( "20","K/018","Potongan Pembelian","KA/018","Laibilitas","Kas & Bank","admin","","2016-08-15 14:12:11");


--
-- Tabel structure for table `detail_item_keluar`
--
DROP TABLE  IF EXISTS `detail_item_keluar`;
CREATE TABLE `detail_item_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `gudang_item_keluar` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `detail_item_keluar`  VALUES ( "1","1/IK/08/16","2016-08-22","08:55:16","BB1","CUP 240ML DELTAPACK","","1","PCS","150","150");


--
-- Tabel structure for table `detail_item_masuk`
--
DROP TABLE  IF EXISTS `detail_item_masuk`;
CREATE TABLE `detail_item_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `gudang_item_masuk` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  `jam` time NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `detail_item_masuk`  VALUES ( "1","1/IM/08/16","2016-08-20","BB1","CUP 240ML DELTAPACK","","4","PCS","150","600","14:05:22","2016-08-20 14:05:22");


--
-- Tabel structure for table `detail_kas_keluar`
--
DROP TABLE  IF EXISTS `detail_kas_keluar`;
CREATE TABLE `detail_kas_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `dari_akun` varchar(100) NOT NULL,
  `ke_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `detail_kas_keluar`  VALUES ( "3","1/KK/08/16","","K/001","K/003","10000","2016-08-22","12:59:34","admin");
INSERT INTO `detail_kas_keluar`  VALUES ( "14","2/KK/08/16","","K/001","K/003","1000","2016-08-23","15:59:25","admin");
INSERT INTO `detail_kas_keluar`  VALUES ( "15","2/KK/08/16","","K/001","K/013","500","2016-08-23","15:59:29","admin");


--
-- Tabel structure for table `detail_kas_masuk`
--
DROP TABLE  IF EXISTS `detail_kas_masuk`;
CREATE TABLE `detail_kas_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `dari_akun` varchar(100) NOT NULL,
  `ke_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `detail_kas_masuk`  VALUES ( "17","1/KM/08/16","","K/005","K/001","20000000","2016-08-19","13:37:33","admin");


--
-- Tabel structure for table `detail_pembayaran_hutang`
--
DROP TABLE  IF EXISTS `detail_pembayaran_hutang`;
CREATE TABLE `detail_pembayaran_hutang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_pembayaran` varchar(100) NOT NULL,
  `no_faktur_pembelian` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date NOT NULL,
  `kredit` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `jumlah_bayar` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `detail_pembayaran_hutang`  VALUES ( "13","1/PH/08/16","3/BL/08/16","2016-08-24","2016-08-27","500","300","200","200");


--
-- Tabel structure for table `detail_pembayaran_piutang`
--
DROP TABLE  IF EXISTS `detail_pembayaran_piutang`;
CREATE TABLE `detail_pembayaran_piutang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_pembayaran` varchar(100) NOT NULL,
  `no_faktur_penjualan` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date NOT NULL,
  `kredit` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `jumlah_bayar` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `detail_pembayaran_piutang`  VALUES ( "3","1/PP/08/16","6/JL/08/16","2016-08-24","2016-08-31","1500","1000","500","500");


--
-- Tabel structure for table `detail_pembelian`
--
DROP TABLE  IF EXISTS `detail_pembelian`;
CREATE TABLE `detail_pembelian` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `waktu` datetime NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` varchar(50) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `harga` int(50) NOT NULL,
  `subtotal` int(50) NOT NULL,
  `potongan` int(50) NOT NULL,
  `tax` int(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

INSERT INTO `detail_pembelian`  VALUES ( "91","1/BL/08/16","2016-08-19","13:38:10","2016-08-19 13:38:10","BB1","CUP 240ML DELTAPACK","100","PCS","150","14500","500","1450","","118");
INSERT INTO `detail_pembelian`  VALUES ( "92","2/BL/08/16","2016-08-20","08:55:04","2016-08-20 08:55:04","BB1","CUP 240ML DELTAPACK","5","PCS","150","600","150","0","","5");
INSERT INTO `detail_pembelian`  VALUES ( "93","3/BL/08/16","2016-08-24","08:19:41","2016-08-24 08:19:41","BB1","CUP 240ML DELTAPACK","10","PCS","150","1500","0","0","","10");


--
-- Tabel structure for table `detail_penjualan`
--
DROP TABLE  IF EXISTS `detail_penjualan`;
CREATE TABLE `detail_penjualan` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(50) NOT NULL,
  `kode_meja` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` varchar(50) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `harga` int(50) NOT NULL,
  `subtotal` int(50) NOT NULL,
  `potongan` int(50) NOT NULL,
  `tax` int(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `hpp` int(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  `no_pesanan` int(100) NOT NULL,
  `komentar` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

INSERT INTO `detail_penjualan`  VALUES ( "42","1/JL/08/16","","2016-08-19","13:38:48","BB1","CUP 240ML DELTAPACK","10","PCS","1000","9500","500","950","","0","7","0","");
INSERT INTO `detail_penjualan`  VALUES ( "44","2/JL/08/16","","2016-08-20","08:29:39","BB1","CUP 240ML DELTAPACK","2","PCS","1000","1300","700","130","","0","2","0","");
INSERT INTO `detail_penjualan`  VALUES ( "45","3/JL/08/16","","2016-08-20","08:52:36","BB1","CUP 240ML DELTAPACK","2","PCS","1000","1900","100","0","","0","2","0","");
INSERT INTO `detail_penjualan`  VALUES ( "46","4/JL/08/16","","2016-08-20","09:03:03","BB1","CUP 240ML DELTAPACK","5","PCS","1000","4000","1000","0","","0","5","0","");
INSERT INTO `detail_penjualan`  VALUES ( "47","5/JL/08/16","","2016-08-20","09:11:28","BB1","CUP 240ML DELTAPACK","2","PCS","1000","1900","100","190","","0","2","0","");
INSERT INTO `detail_penjualan`  VALUES ( "48","6/JL/08/16","","2016-08-24","09:27:56","BB1","CUP 240ML DELTAPACK","5","PCS","1000","5000","0","0","","0","5","0","");


--
-- Tabel structure for table `detail_retur_pembelian`
--
DROP TABLE  IF EXISTS `detail_retur_pembelian`;
CREATE TABLE `detail_retur_pembelian` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_retur` varchar(100) NOT NULL,
  `no_faktur_pembelian` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah_beli` int(100) NOT NULL,
  `jumlah_retur` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  `potongan` int(10) NOT NULL,
  `tax` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `detail_retur_pembelian`  VALUES ( "11","1/RB/08/16","1/BL/08/16","2016-08-19","00:00:00","BB1","CUP 240ML DELTAPACK","100","10","150","1000","500","100");


--
-- Tabel structure for table `detail_retur_penjualan`
--
DROP TABLE  IF EXISTS `detail_retur_penjualan`;
CREATE TABLE `detail_retur_penjualan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_retur` varchar(100) NOT NULL,
  `no_faktur_penjualan` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `waktu` datetime NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah_beli` int(100) NOT NULL,
  `jumlah_retur` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `detail_retur_penjualan`  VALUES ( "18","1/RJ/08/16","1/JL/08/16","2016-08-19","00:00:00","0000-00-00 00:00:00","BB1","CUP 240ML DELTAPACK","10","2","1000","1500","500","150");
INSERT INTO `detail_retur_penjualan`  VALUES ( "20","2/RJ/08/16","1/JL/08/16","2016-08-19","00:00:00","0000-00-00 00:00:00","BB1","CUP 240ML DELTAPACK","10","2","1000","1500","500","0");


--
-- Tabel structure for table `detail_stok_opname`
--
DROP TABLE  IF EXISTS `detail_stok_opname`;
CREATE TABLE `detail_stok_opname` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `awal` varchar(100) NOT NULL,
  `masuk` varchar(100) NOT NULL,
  `keluar` varchar(100) NOT NULL,
  `stok_sekarang` int(100) NOT NULL,
  `fisik` int(100) NOT NULL,
  `selisih_fisik` int(100) NOT NULL,
  `selisih_harga` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `hpp` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `fee_faktur`
--
DROP TABLE  IF EXISTS `fee_faktur`;
CREATE TABLE `fee_faktur` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(100) NOT NULL,
  `jumlah_prosentase` int(100) NOT NULL,
  `jumlah_uang` int(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `fee_produk`
--
DROP TABLE  IF EXISTS `fee_produk`;
CREATE TABLE `fee_produk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_prosentase` int(100) NOT NULL,
  `jumlah_uang` int(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `grup_akun`
--
DROP TABLE  IF EXISTS `grup_akun`;
CREATE TABLE `grup_akun` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kode_grup_akun` varchar(100) NOT NULL,
  `nama_grup_akun` varchar(100) NOT NULL,
  `parent` varchar(100) NOT NULL,
  `kategori_akun` varchar(100) NOT NULL,
  `tipe_akun` varchar(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `grup_akun`  VALUES ( "21","KA/002","Persediaan","KA/001","Aset","Persediaan","Team 3","","2016-07-02 11:57:50");
INSERT INTO `grup_akun`  VALUES ( "22","KA/001","Kas","KA/002","Aset","Kas & Bank","Team 3","","2016-07-02 11:59:12");
INSERT INTO `grup_akun`  VALUES ( "23","KA/003","Hutang","KA/002","Biaya","Hutang Dagang","Team 3","","2016-07-02 11:59:56");
INSERT INTO `grup_akun`  VALUES ( "24","KA/004","Hutang Pajak","KA/001","Laibilitas","Pajak Dibayar Dimuka","Team 3","Team 3","2016-07-02 12:00:52");
INSERT INTO `grup_akun`  VALUES ( "25","KA/006","Item Masuk","KA/002","Aset","Persediaan","Team 3","","2016-07-02 17:02:23");
INSERT INTO `grup_akun`  VALUES ( "26","KA/005","Item Keluar","KA/002","Aset","Persediaan","Team 3","","2016-07-04 15:19:51");
INSERT INTO `grup_akun`  VALUES ( "27","KA/007","Retur Penjualan","KA/002","Aset","Persediaan","Team 3","","2016-07-04 16:06:18");
INSERT INTO `grup_akun`  VALUES ( "28","KA/008","Retur Pembelian","KA/002","Aset","Persediaan","Team 3","","2016-07-04 16:06:39");
INSERT INTO `grup_akun`  VALUES ( "29","KA/009","Potongan Penjualan","KA/001","Aset","Beban Penjualan","Team 3","Team 3","2016-07-05 09:04:37");
INSERT INTO `grup_akun`  VALUES ( "30","KA/010","Pajak Penjualan","KA/006","Biaya","Beban Pajak Penghasilan","Team 3","","2016-07-05 09:07:05");
INSERT INTO `grup_akun`  VALUES ( "31","KA/011","Komisi Sales","KA/001","Biaya","Beban Penjualan","Team 3","","2016-07-05 09:10:09");
INSERT INTO `grup_akun`  VALUES ( "32","KA/012","Total Penjualan","KA/001","Pendapatan","Pendapatan Penjualan","Team 3","","2016-07-05 09:11:47");
INSERT INTO `grup_akun`  VALUES ( "33","KA/013","Pembayaran Kredit","KA/001","Pendapatan","Pendapatan Diterima Dimuka","Team 3","","2016-07-05 09:12:37");
INSERT INTO `grup_akun`  VALUES ( "34","KA/015","Hpp Penjualan","KA/012","Laibilitas","Harga Pokok Penjualan","Team 3","","2016-07-05 09:31:32");
INSERT INTO `grup_akun`  VALUES ( "35","KA/018","Potongan Pembelian","KA/001","Laibilitas","Kas & Bank","admin","","2016-08-15 14:11:42");


--
-- Tabel structure for table `gudang`
--
DROP TABLE  IF EXISTS `gudang`;
CREATE TABLE `gudang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kode_gudang` varchar(100) NOT NULL,
  `nama_gudang` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `gudang`  VALUES ( "8","GD001","Gudang A");
INSERT INTO `gudang`  VALUES ( "9","GD002","Gudang B");
INSERT INTO `gudang`  VALUES ( "16","Gd003","Gudang C");
INSERT INTO `gudang`  VALUES ( "18","GD004","Gudang D");
INSERT INTO `gudang`  VALUES ( "27","GD005","Gudang E");


--
-- Tabel structure for table `hak_otoritas`
--
DROP TABLE  IF EXISTS `hak_otoritas`;
CREATE TABLE `hak_otoritas` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `hak_otoritas`  VALUES ( "10","Pimpinan");
INSERT INTO `hak_otoritas`  VALUES ( "22","Cashier");
INSERT INTO `hak_otoritas`  VALUES ( "23","Purchasing");
INSERT INTO `hak_otoritas`  VALUES ( "24","Waiters");
INSERT INTO `hak_otoritas`  VALUES ( "33","Accounting");


--
-- Tabel structure for table `hpp`
--
DROP TABLE  IF EXISTS `hpp`;
CREATE TABLE `hpp` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `tipe` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `harga_satuan` int(100) NOT NULL,
  `jumlah_kuantitas` int(100) NOT NULL,
  `jumlah_nilai` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` datetime NOT NULL,
  `kuantitas_akhir` int(100) NOT NULL,
  `saldo_akhir` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `hpp_barang`
--
DROP TABLE  IF EXISTS `hpp_barang`;
CREATE TABLE `hpp_barang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `hpp_keluar`
--
DROP TABLE  IF EXISTS `hpp_keluar`;
CREATE TABLE `hpp_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `no_faktur_hpp_masuk` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `jenis_transaksi` varchar(100) NOT NULL,
  `jumlah_kuantitas` int(100) NOT NULL,
  `harga_unit` int(100) NOT NULL,
  `total_nilai` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `waktu` datetime NOT NULL,
  `sisa_barang` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

INSERT INTO `hpp_keluar`  VALUES ( "65","1/JL/08/16","1/BL/08/16","BB1","Penjualan","10","150","1500","2016-08-19","13:38:48","0000-00-00 00:00:00","6");
INSERT INTO `hpp_keluar`  VALUES ( "76","1/RB/08/16","1/BL/08/16","BB1","Retur Pembelian","10","150","1500","2016-08-19","00:00:00","0000-00-00 00:00:00","10");
INSERT INTO `hpp_keluar`  VALUES ( "78","2/JL/08/16","1/BL/08/16","BB1","Penjualan","2","150","300","2016-08-20","08:29:39","0000-00-00 00:00:00","2");
INSERT INTO `hpp_keluar`  VALUES ( "79","3/JL/08/16","1/BL/08/16","BB1","Penjualan","2","150","300","2016-08-20","08:52:36","0000-00-00 00:00:00","2");
INSERT INTO `hpp_keluar`  VALUES ( "80","4/JL/08/16","1/BL/08/16","BB1","Penjualan","5","150","750","2016-08-20","09:03:03","0000-00-00 00:00:00","5");
INSERT INTO `hpp_keluar`  VALUES ( "81","5/JL/08/16","1/BL/08/16","BB1","Penjualan","2","150","300","2016-08-20","09:11:28","0000-00-00 00:00:00","2");
INSERT INTO `hpp_keluar`  VALUES ( "82","1/IK/08/16","1/BL/08/16","BB1","Item Keluar","1","150","150","2016-08-22","08:55:16","0000-00-00 00:00:00","1");
INSERT INTO `hpp_keluar`  VALUES ( "83","6/JL/08/16","1/BL/08/16","BB1","Penjualan","5","150","750","2016-08-24","09:27:56","0000-00-00 00:00:00","5");


--
-- Tabel structure for table `hpp_masuk`
--
DROP TABLE  IF EXISTS `hpp_masuk`;
CREATE TABLE `hpp_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `no_faktur_hpp_keluar` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `jenis_transaksi` varchar(100) NOT NULL,
  `jumlah_kuantitas` int(100) NOT NULL,
  `harga_unit` int(100) NOT NULL,
  `total_nilai` int(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;

INSERT INTO `hpp_masuk`  VALUES ( "107","1/BL/08/16","","BB1","Pembelian","100","150","14500","63","2016-08-19","13:38:10","2016-08-19 13:38:10");
INSERT INTO `hpp_masuk`  VALUES ( "120","1/RJ/08/16","1/JL/08/16","BB1","Retur Penjualan","2","150","300","2","2016-08-19","00:00:00","0000-00-00 00:00:00");
INSERT INTO `hpp_masuk`  VALUES ( "122","2/RJ/08/16","1/JL/08/16","BB1","Retur Penjualan","2","150","300","2","2016-08-19","00:00:00","0000-00-00 00:00:00");
INSERT INTO `hpp_masuk`  VALUES ( "123","2/BL/08/16","","BB1","Pembelian","5","150","600","5","2016-08-20","08:55:04","2016-08-20 08:55:04");
INSERT INTO `hpp_masuk`  VALUES ( "124","1/IM/08/16","","BB1","Item Masuk","4","150","600","4","2016-08-20","14:05:22","2016-08-20 14:05:22");
INSERT INTO `hpp_masuk`  VALUES ( "125","3/BL/08/16","","BB1","Pembelian","10","150","1500","10","2016-08-24","08:19:41","2016-08-24 08:19:41");


--
-- Tabel structure for table `item_keluar`
--
DROP TABLE  IF EXISTS `item_keluar`;
CREATE TABLE `item_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `kode_gudang` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `tanggal_edit` date DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `item_keluar`  VALUES ( "1","1/IK/08/16","","2016-08-22","08:55:16","admin","","","","150");


--
-- Tabel structure for table `item_masuk`
--
DROP TABLE  IF EXISTS `item_masuk`;
CREATE TABLE `item_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `kode_gudang` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `tanggal_edit` date DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `item_masuk`  VALUES ( "1","1/IM/08/16","","2016-08-20","14:05:22","admin","","","","600");


--
-- Tabel structure for table `jabatan`
--
DROP TABLE  IF EXISTS `jabatan`;
CREATE TABLE `jabatan` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `wewenang` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `jabatan`  VALUES ( "3","Pimpinan","");
INSERT INTO `jabatan`  VALUES ( "6","Cashier","");
INSERT INTO `jabatan`  VALUES ( "8","Waiter","");
INSERT INTO `jabatan`  VALUES ( "9","Accounting","");
INSERT INTO `jabatan`  VALUES ( "10","Purchasing","");
INSERT INTO `jabatan`  VALUES ( "13","captain","mengontrol kinerja waiter dan waiters");


--
-- Tabel structure for table `jurnal_trans`
--
DROP TABLE  IF EXISTS `jurnal_trans`;
CREATE TABLE `jurnal_trans` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nomor_jurnal` varchar(100) NOT NULL,
  `waktu_jurnal` datetime NOT NULL,
  `keterangan_jurnal` varchar(100) NOT NULL,
  `kode_akun_jurnal` varchar(100) NOT NULL,
  `debit` int(100) NOT NULL,
  `kredit` int(100) NOT NULL,
  `jenis_transaksi` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `approved` int(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1304 DEFAULT CHARSET=latin1;

INSERT INTO `jurnal_trans`  VALUES ( "861","1/JR/08/16","2016-08-19 13:37:35","Transaksi Kas Masuk ke ","K/001","20000000","0","Kas Masuk","1/KM/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "862","2/JR/08/16","2016-08-19 13:37:35","Transaksi Kas Masuk dari ","K/005","0","20000000","Kas Masuk","1/KM/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "863","3/JR/08/16","2016-08-19 13:38:10","Pembelian Tunai - Sukanda","K/002","13050","0","Pembelian","1/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "864","4/JR/08/16","2016-08-19 13:38:10","Pembelian Tunai - Sukanda","K/003","1450","0","Pembelian","1/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "865","5/JR/08/16","2016-08-19 13:38:10","Pembelian Tunai - Sukanda","K/001","0","13050","Pembelian","1/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "866","6/JR/08/16","2016-08-19 13:38:10","Pembelian Tunai - Sukanda","K/018","0","1450","Pembelian","1/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "867","7/JR/08/16","2016-08-19 13:38:48","Penjualan Tunai - Ajoya","K/002","0","1500","Penjualan","1/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "868","7/JR/08/16","2016-08-19 13:38:48","Penjualan Tunai - Ajoya","K/015","1500","0","Penjualan","1/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "869","7/JR/08/16","2016-08-19 13:38:48","Penjualan Tunai - Ajoya","K/001","8550","0","Penjualan","1/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "870","7/JR/08/16","2016-08-19 13:38:48","Penjualan Tunai - Ajoya","K/014","0","8550","Penjualan","1/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "871","7/JR/08/16","2016-08-19 13:38:48","Penjualan Tunai - Ajoya","K/011","0","950","Penjualan","1/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "872","7/JR/08/16","2016-08-19 13:38:48","Penjualan Tunai - Ajoya","K/010","950","0","Penjualan","1/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "925","8/JR/08/16","2016-08-19 14:02:49","Retur Penjualan - Ajoya","K/002","300","0","Retur Penjualan","1/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "926","9/JR/08/16","2016-08-19 14:02:49","Retur Penjualan - Ajoya","K/001","0","1000","Retur Penjualan","1/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "927","9/JR/08/16","2016-08-19 14:02:49","Retur Penjualan - Ajoya","K/015","0","300","Retur Penjualan","1/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "928","10/JR/08/16","2016-08-19 14:02:49","Retur Penjualan - Ajoya","K/011","150","0","Retur Penjualan","1/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "929","11/JR/08/16","2016-08-19 14:02:49","Retur Penjualan - Ajoya","K/014","1350","0","Penjualan","1/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "930","12/JR/08/16","2016-08-19 14:02:49","Retur Penjualan - Ajoya","K/010","0","500","Retur Penjualan","1/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "937","13/JR/08/16","2016-08-19 14:06:36","Retur Penjualan - Ajoya","K/002","300","0","Retur Penjualan","2/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "938","14/JR/08/16","2016-08-19 14:06:36","Retur Penjualan - Ajoya","K/015","0","300","Retur Penjualan","2/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "939","15/JR/08/16","2016-08-19 14:06:36","Retur Penjualan - Ajoya","K/001","0","1100","Retur Penjualan","2/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "940","16/JR/08/16","2016-08-19 14:06:36","Retur Penjualan - Ajoya","K/011","100","0","Retur Penjualan","2/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "941","17/JR/08/16","2016-08-19 14:06:36","Retur Penjualan - Ajoya","K/014","1500","0","Penjualan","2/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "942","18/JR/08/16","2016-08-19 14:06:36","Retur Penjualan - Ajoya","K/010","0","500","Retur Penjualan","2/RJ/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "982","19/JR/08/16","2016-08-19 15:19:57","Retur Pembelian - Sukanda","K/002","0","900","Retur Pembelian","1/RB/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "983","20/JR/08/16","2016-08-19 15:19:57","Retur Pembelian - Sukanda","K/003","0","100","Retur Pembelian","1/RB/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "984","21/JR/08/16","2016-08-19 15:19:57","Retur Pembelian - Sukanda","K/001","500","0","Retur Pembelian","1/RB/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "985","22/JR/08/16","2016-08-19 15:19:57","Retur Pembelian - Sukanda","K/018","500","0","Retur Pembelian","1/RB/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "992","23/JR/08/16","2016-08-20 08:29:39","Penjualan Tunai - Ajoya","K/002","0","300","Penjualan","2/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "993","23/JR/08/16","2016-08-20 08:29:39","Penjualan Tunai - Ajoya","K/015","300","0","Penjualan","2/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "994","23/JR/08/16","2016-08-20 08:29:39","Penjualan Tunai - Ajoya","K/001","1040","0","Penjualan","2/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "995","23/JR/08/16","2016-08-20 08:29:39","Penjualan Tunai - Ajoya","K/014","0","1170","Penjualan","2/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "996","23/JR/08/16","2016-08-20 08:29:39","Penjualan Tunai - Ajoya","K/011","0","130","Penjualan","2/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "997","23/JR/08/16","2016-08-20 08:29:39","Penjualan Tunai - Ajoya","K/010","260","0","Penjualan","2/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "998","24/JR/08/16","2016-08-20 08:52:36","Penjualan Tunai - Ajoya","K/002","0","300","Penjualan","3/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "999","24/JR/08/16","2016-08-20 08:52:36","Penjualan Tunai - Ajoya","K/015","300","0","Penjualan","3/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1000","24/JR/08/16","2016-08-20 08:52:36","Penjualan Tunai - Ajoya","K/001","2052","0","Penjualan","3/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1001","24/JR/08/16","2016-08-20 08:52:36","Penjualan Tunai - Ajoya","K/014","0","1900","Penjualan","3/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1002","24/JR/08/16","2016-08-20 08:52:36","Penjualan Tunai - Ajoya","K/011","0","342","Penjualan","3/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1003","24/JR/08/16","2016-08-20 08:52:36","Penjualan Tunai - Ajoya","K/010","190","0","Penjualan","3/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1004","25/JR/08/16","2016-08-20 08:55:04","Pembelian Tunai - Sukanda","K/002","600","0","Pembelian","2/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1005","26/JR/08/16","2016-08-20 08:55:04","Pembelian Tunai - Sukanda","K/003","108","0","Pembelian","2/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1006","27/JR/08/16","2016-08-20 08:55:04","Pembelian Tunai - Sukanda","K/001","0","648","Pembelian","2/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1007","28/JR/08/16","2016-08-20 08:55:04","Pembelian Tunai - Sukanda","K/018","0","60","Pembelian","2/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1008","29/JR/08/16","2016-08-20 09:03:03","Penjualan Tunai - Ajoya","K/002","0","750","Penjualan","4/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1009","29/JR/08/16","2016-08-20 09:03:03","Penjualan Tunai - Ajoya","K/015","750","0","Penjualan","4/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1010","29/JR/08/16","2016-08-20 09:03:03","Penjualan Tunai - Ajoya","K/001","3600","0","Penjualan","4/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1011","29/JR/08/16","2016-08-20 09:03:03","Penjualan Tunai - Ajoya","K/014","0","4000","Penjualan","4/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1012","29/JR/08/16","2016-08-20 09:03:03","Penjualan Tunai - Ajoya","K/010","400","0","Penjualan","4/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1013","30/JR/08/16","2016-08-20 09:11:28","Penjualan Tunai - Ajoya","K/002","0","300","Penjualan","5/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1014","30/JR/08/16","2016-08-20 09:11:28","Penjualan Tunai - Ajoya","K/015","300","0","Penjualan","5/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1015","30/JR/08/16","2016-08-20 09:11:28","Penjualan Tunai - Ajoya","K/001","1710","0","Penjualan","5/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1016","30/JR/08/16","2016-08-20 09:11:28","Penjualan Tunai - Ajoya","K/014","0","1710","Penjualan","5/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1017","30/JR/08/16","2016-08-20 09:11:28","Penjualan Tunai - Ajoya","K/011","0","190","Penjualan","5/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1018","30/JR/08/16","2016-08-20 09:11:28","Penjualan Tunai - Ajoya","K/010","190","0","Penjualan","5/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1043","37/JR/08/16","2016-08-20 14:05:22","Persediaan -","K/002","600","0","Item Masuk","1/IM/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1044","38/JR/08/16","2016-08-20 14:05:22","Item Masuk -","K/006","0","600","Item Masuk","1/IM/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1047","39/JR/08/16","2016-08-22 08:55:16","Persediaan -","K/002","0","150","Item Keluar","1/IK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1048","40/JR/08/16","2016-08-22 08:55:16","Item Keluar -","K/007","150","0","Item Masuk","1/IK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1089","48/JR/08/16","2016-08-22 12:55:46","Transaksi Kas Mutasi ke Modal","K/005","1000","0","Kas Mutasi","2/KMT/08/16	","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1090","49/JR/08/16","2016-08-22 12:55:46","Transaksi Kas Mutasi dari Kas","K/001","0","1000","Kas Mutasi","2/KMT/08/16	","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1091","50/JR/08/16","2016-08-22 13:05:23","Transaksi Kas Keluar dari Kas","K/001","0","10000","Kas Keluar","1/KK/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1092","51/JR/08/16","2016-08-22 13:05:23","Transaksi Kas Keluar ke Pajak","K/003","10000","0","Kas Keluar","1/KK/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1093","52/JR/08/16","2016-08-22 13:05:23","Transaksi Kas Keluar dari Kas","K/001","0","10000","Kas Keluar","1/KK/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1094","53/JR/08/16","2016-08-22 12:57:30","Transaksi Kas Keluar ke ","K/004","10000","0","Kas Keluar","1/KK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1161","54/JR/08/16","2016-08-22 15:09:30","Jurnal Manual - ","K/001","1000","0","Jurnal Manual","4/JM/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1162","55/JR/08/16","2016-08-22 15:09:30","Jurnal Manual - ","K/003","0","1000","Jurnal Manual","4/JM/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1171","58/JR/08/16","2016-08-23 14:31:54","Transaksi Kas Mutasi ke Modal","K/005","1000","0","Kas Mutasi","3/KMT/08/16	","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1172","59/JR/08/16","2016-08-23 14:31:54","Transaksi Kas Mutasi dari Kas","K/001","0","1000","Kas Mutasi","3/KMT/08/16	","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1179","60/JR/08/16","2016-08-23 15:59:34","Transaksi Kas Keluar dari Kas","K/001","0","1000","Kas Keluar","2/KK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1180","61/JR/08/16","2016-08-23 15:59:34","Transaksi Kas Keluar ke Pajak","K/003","1000","0","Kas Keluar","2/KK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1181","62/JR/08/16","2016-08-23 15:59:34","Transaksi Kas Keluar dari Kas","K/001","0","500","Kas Keluar","2/KK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1182","63/JR/08/16","2016-08-23 15:59:34","Transaksi Kas Keluar ke ","K/013","500","0","Kas Keluar","2/KK/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1183","64/JR/08/16","2016-08-24 08:19:41","Pembelian Hutang - Kopiku","K/002","1500","0","Pembelian","3/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1184","65/JR/08/16","2016-08-24 08:19:41","Pembelian Hutang - Kopiku","K/003","0","0","Pembelian","3/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1185","66/JR/08/16","2016-08-24 08:19:41","Pembelian Hutang - Kopiku","K/004","0","500","Pembelian","3/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1186","67/JR/08/16","2016-08-24 08:19:41","Pembelian Hutang - Kopiku","K/001","0","1000","Pembelian","3/BL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1215","68/JR/08/16","2016-08-24 09:25:07","Pembayaran Hutang - Kopiku","K/004","200","0","Pembayaran Hutang","1/PH/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1216","69/JR/08/16","2016-08-24 09:25:07","Pembayaran Hutang - Kopiku","K/001","0","200","Pembayaran Hutang","1/PH/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1217","70/JR/08/16","2016-08-24 09:27:56","Penjualan Tunai - Ajoya","K/002","0","750","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1218","70/JR/08/16","2016-08-24 09:27:56","Penjualan Tunai - Ajoya","K/015","750","0","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1219","70/JR/08/16","2016-08-24 09:27:56","Penjualan Tunai - Ajoya","K/001","3000","0","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1220","70/JR/08/16","2016-08-24 09:27:56","Penjualan Piutang - Ajoya","K/013","1500","0","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1221","70/JR/08/16","2016-08-24 09:27:56","Penjualan Tunai - Ajoya","K/014","0","5000","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1222","70/JR/08/16","2016-08-24 09:27:56","Penjualan Tunai - Ajoya","K/011","0","0","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1223","70/JR/08/16","2016-08-24 09:27:56","Penjualan Tunai - Ajoya","K/010","500","0","Penjualan","6/JL/08/16","1","admin","");
INSERT INTO `jurnal_trans`  VALUES ( "1228","71/JR/08/16","2016-08-24 09:53:02","Pembayaran Piutang - Ajoya","K/001","500","0","Pembayaran Piutang","1/PP/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1229","72/JR/08/16","2016-08-24 09:53:02","Pembayaran Piutang - Ajoya","K/013","0","500","Pembayaran Piutang","1/PP/08/16","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1302","73/JR/08/16","2016-08-24 11:40:22","Transaksi Kas Mutasi ke Modal","K/005","1000","0","Kas Mutasi","4/KMT/08/16	","1","admin","admin");
INSERT INTO `jurnal_trans`  VALUES ( "1303","74/JR/08/16","2016-08-24 11:40:22","Transaksi Kas Mutasi dari Kas","K/001","0","1000","Kas Mutasi","4/KMT/08/16	","1","admin","admin");


--
-- Tabel structure for table `kartu_stok`
--
DROP TABLE  IF EXISTS `kartu_stok`;
CREATE TABLE `kartu_stok` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tipe` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `suplier_pelanggan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `kas`
--
DROP TABLE  IF EXISTS `kas`;
CREATE TABLE `kas` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `kas`  VALUES ( "1","KAS PENJUALAN","1214800","");
INSERT INTO `kas`  VALUES ( "2","KAS PEMEBLIAN","11967560","");
INSERT INTO `kas`  VALUES ( "3","KAS LAIN - LAIN","135000","");


--
-- Tabel structure for table `kas_keluar`
--
DROP TABLE  IF EXISTS `kas_keluar`;
CREATE TABLE `kas_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `dari_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `kas_keluar`  VALUES ( "1","1/KK/08/16","","K/001","10000","2016-08-22","13:05:23","admin");
INSERT INTO `kas_keluar`  VALUES ( "4","2/KK/08/16","","K/001","1500","2016-08-23","15:59:34","admin");


--
-- Tabel structure for table `kas_masuk`
--
DROP TABLE  IF EXISTS `kas_masuk`;
CREATE TABLE `kas_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `ke_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `kas_masuk`  VALUES ( "12","1/KM/08/16","","K/001","20000000","2016-08-19","13:37:35","admin");


--
-- Tabel structure for table `kas_mutasi`
--
DROP TABLE  IF EXISTS `kas_mutasi`;
CREATE TABLE `kas_mutasi` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `dari_akun` varchar(100) NOT NULL,
  `ke_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `kas_mutasi`  VALUES ( "2","2/KMT/08/16	","asd","K/001","K/005","1000","2016-08-22","12:55:46","admin");
INSERT INTO `kas_mutasi`  VALUES ( "3","3/KMT/08/16	","","K/001","K/005","1000","2016-08-23","14:31:54","admin");
INSERT INTO `kas_mutasi`  VALUES ( "12","4/KMT/08/16	","Tes Jurnal","K/001","K/005","1000","2016-08-24","11:40:22","admin");


--
-- Tabel structure for table `kategori`
--
DROP TABLE  IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `kategori`  VALUES ( "1","Kategori Makanan");
INSERT INTO `kategori`  VALUES ( "2","Kategori Minuman");
INSERT INTO `kategori`  VALUES ( "4","Obat - obatan");
INSERT INTO `kategori`  VALUES ( "6","Lain - lain");


--
-- Tabel structure for table `laporan_fee_faktur`
--
DROP TABLE  IF EXISTS `laporan_fee_faktur`;
CREATE TABLE `laporan_fee_faktur` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `jumlah_fee` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `status_bayar` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `laporan_fee_produk`
--
DROP TABLE  IF EXISTS `laporan_fee_produk`;
CREATE TABLE `laporan_fee_produk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_fee` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `status_bayar` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `meja`
--
DROP TABLE  IF EXISTS `meja`;
CREATE TABLE `meja` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kode_meja` varchar(100) NOT NULL,
  `nama_meja` varchar(100) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `status_pakai` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `nomor_faktur_jurnal`
--
DROP TABLE  IF EXISTS `nomor_faktur_jurnal`;
CREATE TABLE `nomor_faktur_jurnal` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_jurnal` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `nomor_faktur_jurnal`  VALUES ( "17","2/JM/08/16","2016-08-22");
INSERT INTO `nomor_faktur_jurnal`  VALUES ( "18","3/JM/08/16","2016-08-22");
INSERT INTO `nomor_faktur_jurnal`  VALUES ( "19","4/JM/08/16","2016-08-22");


--
-- Tabel structure for table `nomor_faktur_stok_awal`
--
DROP TABLE  IF EXISTS `nomor_faktur_stok_awal`;
CREATE TABLE `nomor_faktur_stok_awal` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_stok_awal` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `nomor_faktur_stok_awal`  VALUES ( "5","1/SA/08/16","2016-08-15");
INSERT INTO `nomor_faktur_stok_awal`  VALUES ( "6","2/SA/08/16","2016-08-15");
INSERT INTO `nomor_faktur_stok_awal`  VALUES ( "7","3/SA/08/16","2016-08-15");
INSERT INTO `nomor_faktur_stok_awal`  VALUES ( "8","4/SA/08/16","2016-08-22");


--
-- Tabel structure for table `pelanggan`
--
DROP TABLE  IF EXISTS `pelanggan`;
CREATE TABLE `pelanggan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kode_pelanggan` varchar(100) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `no_telp` varchar(100) NOT NULL,
  `e_mail` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `wilayah` varchar(100) NOT NULL,
  `level_harga` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

INSERT INTO `pelanggan`  VALUES ( "99","01","Ajoya","0823-74175544","","0000-00-00","Gg. Raflesia, Belakang Kolam Renang","Level 1");
INSERT INTO `pelanggan`  VALUES ( "100","02","Ari / Siti Sabar Group","0899-6455570","","0000-00-00","Jl. Pulau Bacan, Depan Perumahan Lidia Garden","Level 1");
INSERT INTO `pelanggan`  VALUES ( "101","03","Ayang Pramudya","","","0000-00-00","Jl. Galunggung Raya- Depan Salon","Level 1");
INSERT INTO `pelanggan`  VALUES ( "102","04","Ardi Jaya Tenda","0812-71477455","","0000-00-00","Jl. Urip Sumoharjo","Level 1");
INSERT INTO `pelanggan`  VALUES ( "103","05","BAMBANG ","0821-86840756","","0000-00-00","Perum Arum Lestari Permai JL. Hendro Suratmin ","Level 1");
INSERT INTO `pelanggan`  VALUES ( "104","06","Bpk Tarmadi/Bpk Heri ","0852-67576610","","0000-00-00","Jl. Airan Raya Gg Hj Asiani , Way Hui","Level 1");
INSERT INTO `pelanggan`  VALUES ( "105","07","Bpk. Handoko","0812-7261011","","0000-00-00","Jl. Satria 3, Korpri","Level 1");
INSERT INTO `pelanggan`  VALUES ( "106","08","Bpk Bambang","0821-85563030","","0000-00-00","Belakang SMP 19 Bandar Lampung","Level 1");
INSERT INTO `pelanggan`  VALUES ( "107","09","Bank Tri Surya","089615488876 /0721-253555","","0000-00-00","JL. Kartini","Level 1");
INSERT INTO `pelanggan`  VALUES ( "108","10","Berliana","0857-69482228/0895-14409646","","0000-00-00","Jl. Sentot Alibasa, Pasar Tempel Sukareame","Level 1");
INSERT INTO `pelanggan`  VALUES ( "109","11","Bi Rum","0812-723322889","","0000-00-00","Umbul Asem (Teluk Betung)","Level 1");
INSERT INTO `pelanggan`  VALUES ( "110","12","Bam s Musik","0877-98836397/0721-788390","","0000-00-00","Ruko Way Halim Permai","Level 1");
INSERT INTO `pelanggan`  VALUES ( "111","13","Bpk. Hj. Candra","0812-79122345","","0000-00-00","Jl. Zainal Pagar Alam, Samping Basic Com","Level 1");
INSERT INTO `pelanggan`  VALUES ( "112","14","BP. TRI WAHYONO","0852-67979618","","0000-00-00","JL. P.Tegal gg apel 2 no 29","Level 1");
INSERT INTO `pelanggan`  VALUES ( "113","15","Bp.Sujari","","","0000-00-00","Sekertariat Camat Way Dadi,jl durian no 99","Level 1");


--
-- Tabel structure for table `pemasukan`
--
DROP TABLE  IF EXISTS `pemasukan`;
CREATE TABLE `pemasukan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=latin1;

INSERT INTO `pemasukan`  VALUES ( "109","Notes Payable");
INSERT INTO `pemasukan`  VALUES ( "110","Original Investment");
INSERT INTO `pemasukan`  VALUES ( "112","Property");
INSERT INTO `pemasukan`  VALUES ( "114","Goodwill");
INSERT INTO `pemasukan`  VALUES ( "119","Equipment");


--
-- Tabel structure for table `pembayaran_hutang`
--
DROP TABLE  IF EXISTS `pembayaran_hutang`;
CREATE TABLE `pembayaran_hutang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_pembayaran` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `nama_suplier` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total` int(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `tanggal_edit` date NOT NULL,
  `dari_kas` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `pembayaran_hutang`  VALUES ( "11","1/PH/08/16","2016-08-24","09:25:06","24","","200","admin","admin","2016-08-24","K/001");


--
-- Tabel structure for table `pembayaran_piutang`
--
DROP TABLE  IF EXISTS `pembayaran_piutang`;
CREATE TABLE `pembayaran_piutang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_pembayaran` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `nama_suplier` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total` int(100) NOT NULL,
  `user_buat` varchar(100) NOT NULL,
  `user_edit` varchar(100) NOT NULL,
  `tanggal_edit` date NOT NULL,
  `dari_kas` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `pembayaran_piutang`  VALUES ( "2","1/PP/08/16","2016-08-24","09:53:02","01"," \n          ","500","admin","admin","2016-08-24","K/001");


--
-- Tabel structure for table `pembelian`
--
DROP TABLE  IF EXISTS `pembelian`;
CREATE TABLE `pembelian` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(50) NOT NULL,
  `kode_gudang` varchar(100) NOT NULL,
  `suplier` varchar(50) NOT NULL,
  `total` int(50) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date DEFAULT NULL,
  `jam` time NOT NULL,
  `user` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `potongan` int(50) DEFAULT NULL,
  `tax` int(50) DEFAULT NULL,
  `sisa` int(100) DEFAULT NULL,
  `kredit` int(100) NOT NULL,
  `nilai_kredit` int(100) NOT NULL,
  `cara_bayar` varchar(100) NOT NULL,
  `tunai` int(100) NOT NULL,
  `status_beli_awal` varchar(100) NOT NULL,
  `ppn` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

INSERT INTO `pembelian`  VALUES ( "67","1/BL/08/16","GD001","23","13050","2016-08-19","","13:38:10","admin","Lunas","1450","0","0","0","0","K/001","13050","Tunai","Include");
INSERT INTO `pembelian`  VALUES ( "68","2/BL/08/16","GD001","23","648","2016-08-20","","08:55:04","admin","Lunas","60","108","52","0","0","K/001","700","Tunai","Exclude");
INSERT INTO `pembelian`  VALUES ( "69","3/BL/08/16","GD001","24","1500","2016-08-24","2016-08-27","08:19:41","admin","Lunas","0","0","","200","500","K/001","1000","Kredit","Include");


--
-- Tabel structure for table `pengeluaran`
--
DROP TABLE  IF EXISTS `pengeluaran`;
CREATE TABLE `pengeluaran` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `pengeluaran`  VALUES ( "5","Property");
INSERT INTO `pengeluaran`  VALUES ( "6","Goodwill");
INSERT INTO `pengeluaran`  VALUES ( "7","Money Repaid");
INSERT INTO `pengeluaran`  VALUES ( "8","Expenses");


--
-- Tabel structure for table `penjualan`
--
DROP TABLE  IF EXISTS `penjualan`;
CREATE TABLE `penjualan` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(50) NOT NULL,
  `kode_gudang` varchar(100) NOT NULL,
  `kode_pelanggan` varchar(50) NOT NULL,
  `kode_meja` varchar(100) NOT NULL,
  `total` int(50) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(50) NOT NULL,
  `sales` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `potongan` int(50) NOT NULL,
  `tax` int(50) NOT NULL,
  `sisa` int(100) NOT NULL,
  `kredit` int(100) NOT NULL,
  `nilai_kredit` int(100) NOT NULL,
  `total_hpp` int(100) NOT NULL,
  `cara_bayar` varchar(100) NOT NULL,
  `tunai` int(100) NOT NULL,
  `ppn` varchar(100) NOT NULL,
  `no_pesanan` int(100) NOT NULL,
  `status_jual_awal` varchar(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

INSERT INTO `penjualan`  VALUES ( "33","1/JL/08/16","GD001","01","","8550","2016-08-19","0000-00-00","13:38:48","admin","Dev 3","Lunas","950","0","0","0","0","0","K/001","8550","Include","0","Tunai"," \n          ");
INSERT INTO `penjualan`  VALUES ( "35","2/JL/08/16","GD001","01","","1040","2016-08-20","0000-00-00","08:29:39","admin","Dev 3","Lunas","260","0","0","0","0","0","K/001","1040","Include","0","Tunai"," \n          ");
INSERT INTO `penjualan`  VALUES ( "36","3/JL/08/16","GD001","01","","2052","2016-08-20","0000-00-00","08:52:36","admin","Dev 3","Lunas","190","342","0","0","0","0","K/001","2052","Exclude","0","Tunai"," \n          ");
INSERT INTO `penjualan`  VALUES ( "37","4/JL/08/16","GD001","01","","3600","2016-08-20","0000-00-00","09:03:03","admin","Dev 3","Lunas","400","0","0","0","0","0","K/001","3600","Non","0","Tunai"," \n          ");
INSERT INTO `penjualan`  VALUES ( "38","5/JL/08/16","GD001","01","","1710","2016-08-20","0000-00-00","09:11:28","admin","Dev 3","Lunas","190","0","0","0","0","0","K/001","1710","Include","0","Tunai"," INCLUDE");
INSERT INTO `penjualan`  VALUES ( "39","6/JL/08/16","GD001","01","","4500","2016-08-24","2016-08-31","09:27:56","admin","Dev 3","Piutang","500","0","0","900","1500","0","K/001","3000","Include","0","Kredit"," \n          ");


--
-- Tabel structure for table `perusahaan`
--
DROP TABLE  IF EXISTS `perusahaan`;
CREATE TABLE `perusahaan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nama_perusahaan` varchar(100) NOT NULL,
  `alamat_perusahaan` varchar(100) NOT NULL,
  `singkatan_perusahaan` varchar(100) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `no_telp` varchar(25) NOT NULL,
  `no_fax` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `perusahaan`  VALUES ( "1","T  E  A  M    #3","Jl. Pramuka, Sentra Bisnis Terminal Kemiling Blok R3 No.7, Kemiling, Kota Bandar Lampung, Lampung ","TEAM 3","book4.jpg","+62 721 273453","-");


--
-- Tabel structure for table `retur_pembelian`
--
DROP TABLE  IF EXISTS `retur_pembelian`;
CREATE TABLE `retur_pembelian` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_retur` varchar(100) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `jam` time NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `nama_suplier` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  `user_buat` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `tanggal_edit` date DEFAULT NULL,
  `cara_bayar` varchar(100) NOT NULL,
  `tunai` int(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  `ppn` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `retur_pembelian`  VALUES ( "8","1/RB/08/16","2016-08-19","15:19:57","","23","","500","500","0","admin","admin","2016-08-19","K/001","500","0","Include");


--
-- Tabel structure for table `retur_penjualan`
--
DROP TABLE  IF EXISTS `retur_penjualan`;
CREATE TABLE `retur_penjualan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur_retur` varchar(100) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `jam` time NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kode_pelanggan` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  `user_buat` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  `tanggal_edit` date DEFAULT NULL,
  `cara_bayar` varchar(100) NOT NULL,
  `tunai` int(100) NOT NULL,
  `sisa` int(100) NOT NULL,
  `ppn` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `retur_penjualan`  VALUES ( "2","1/RJ/08/16","2016-08-19","14:02:49","","01","","1000","500","0","admin","admin","2016-08-19","K/001","1000","0","Include");
INSERT INTO `retur_penjualan`  VALUES ( "3","2/RJ/08/16","2016-08-19","14:06:36","","01","","1100","500","100","admin","admin","2016-08-19","K/001","1100","0","Exclude");


--
-- Tabel structure for table `satuan`
--
DROP TABLE  IF EXISTS `satuan`;
CREATE TABLE `satuan` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `nama_cetak` varchar(100) NOT NULL,
  `dari_satuan` varchar(100) NOT NULL,
  `qty` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=latin1;

INSERT INTO `satuan`  VALUES ( "125","PCS","Pieces","PCS","1");
INSERT INTO `satuan`  VALUES ( "127","KG","Kg","Kg","1");
INSERT INTO `satuan`  VALUES ( "128","Liter","Ltr","Liter","1");
INSERT INTO `satuan`  VALUES ( "130","Botol","Btl","Botol","1");
INSERT INTO `satuan`  VALUES ( "131","Gram","Gr","Gram","1");
INSERT INTO `satuan`  VALUES ( "132","Karton","Krt","Karton","12");
INSERT INTO `satuan`  VALUES ( "133","AKG","AKG","AKG","12");


--
-- Tabel structure for table `setting_akun`
--
DROP TABLE  IF EXISTS `setting_akun`;
CREATE TABLE `setting_akun` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `persediaan` varchar(100) NOT NULL,
  `pajak` varchar(100) NOT NULL,
  `potongan` varchar(100) NOT NULL,
  `hutang` varchar(100) NOT NULL,
  `modal` varchar(100) NOT NULL,
  `kas` varchar(100) NOT NULL,
  `item_masuk` varchar(100) NOT NULL,
  `item_keluar` varchar(100) NOT NULL,
  `retur_penjualan` varchar(100) NOT NULL,
  `retur_pembelian` varchar(100) NOT NULL,
  `potongan_jual` varchar(100) NOT NULL,
  `pajak_jual` varchar(100) NOT NULL,
  `total_penjualan` varchar(100) NOT NULL,
  `pembayaran_kredit` varchar(100) NOT NULL,
  `komisi_sales` varchar(100) NOT NULL,
  `hpp_penjualan` varchar(100) NOT NULL,
  `stok_awal` varchar(100) NOT NULL,
  `pengaturan_stok` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `setting_akun`  VALUES ( "1","K/002","K/003","K/018","K/004","K/005","K/001","K/006","K/007","K/008","K/009","K/010","K/011","K/014","K/013","K/012","K/015","K/016","K/017");


--
-- Tabel structure for table `setting_bahasa`
--
DROP TABLE  IF EXISTS `setting_bahasa`;
CREATE TABLE `setting_bahasa` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `kata_asal` varchar(100) NOT NULL,
  `kata_ubah` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `setting_bahasa`  VALUES ( "1","Sales","Mekanik");
INSERT INTO `setting_bahasa`  VALUES ( "2","Pelanggan","Customer");


--
-- Tabel structure for table `setting_diskon_tax`
--
DROP TABLE  IF EXISTS `setting_diskon_tax`;
CREATE TABLE `setting_diskon_tax` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `diskon_nominal` int(100) NOT NULL,
  `diskon_persen` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `setting_diskon_tax`  VALUES ( "1","0","10","0");


--
-- Tabel structure for table `status_print`
--
DROP TABLE  IF EXISTS `status_print`;
CREATE TABLE `status_print` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `tipe_produk` varchar(100) NOT NULL,
  `no_pesanan` varchar(100) NOT NULL,
  `status_print` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `status_print`  VALUES ( "1","6/JL/08/16","Semua","1","");
INSERT INTO `status_print`  VALUES ( "2","6/JL/08/16","Semua","1","");
INSERT INTO `status_print`  VALUES ( "3","6/JL/08/16","Semua","1","");
INSERT INTO `status_print`  VALUES ( "4","6/JL/08/16","Semua","1","");


--
-- Tabel structure for table `stok_awal`
--
DROP TABLE  IF EXISTS `stok_awal`;
CREATE TABLE `stok_awal` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah_awal` int(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `gudang` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  `tanggal_edit` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `stok_opname`
--
DROP TABLE  IF EXISTS `stok_opname`;
CREATE TABLE `stok_opname` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `no_faktur` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `status` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `total_selisih` int(100) NOT NULL,
  `hpp` int(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `suplier`
--
DROP TABLE  IF EXISTS `suplier`;
CREATE TABLE `suplier` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `suplier`  VALUES ( "23","Sukanda","Palembang","081271649982");
INSERT INTO `suplier`  VALUES ( "24","Kopiku","Jakarta","0217207273");
INSERT INTO `suplier`  VALUES ( "25","Aladin","Jl  pahoman ","08523697425");
INSERT INTO `suplier`  VALUES ( "26","Pasar","Yudha","089552654552");
INSERT INTO `suplier`  VALUES ( "27","Limas raga","Lampung","085380672555");
INSERT INTO `suplier`  VALUES ( "28","Livi","Lampung","081316649612");
INSERT INTO `suplier`  VALUES ( "29","Coca cola","Lampung","082176899445");
INSERT INTO `suplier`  VALUES ( "31","Fajar agung","Lampung","085236985");
INSERT INTO `suplier`  VALUES ( "32","Cemindo","Lampung","081369575889");
INSERT INTO `suplier`  VALUES ( "33","Coca cola","Lampung","082176899445");


--
-- Tabel structure for table `tbs_fee_produk`
--
DROP TABLE  IF EXISTS `tbs_fee_produk`;
CREATE TABLE `tbs_fee_produk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `nama_petugas` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_fee` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_item_keluar`
--
DROP TABLE  IF EXISTS `tbs_item_keluar`;
CREATE TABLE `tbs_item_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbs_item_keluar`  VALUES ( "1","","1/IK/08/16","BB1","CUP 240ML DELTAPACK","1","PCS","150","150");


--
-- Tabel structure for table `tbs_item_masuk`
--
DROP TABLE  IF EXISTS `tbs_item_masuk`;
CREATE TABLE `tbs_item_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_jurnal`
--
DROP TABLE  IF EXISTS `tbs_jurnal`;
CREATE TABLE `tbs_jurnal` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `kode_akun_jurnal` varchar(100) NOT NULL,
  `nama_akun_jurnal` varchar(100) NOT NULL,
  `debit` int(100) NOT NULL,
  `kredit` int(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=latin1;

INSERT INTO `tbs_jurnal`  VALUES ( "130","hftrbk8mhln314fappri14f7q4","K/001","Kas","1000","0","");
INSERT INTO `tbs_jurnal`  VALUES ( "131","hftrbk8mhln314fappri14f7q4","K/003","Pajak","0","1000","");
INSERT INTO `tbs_jurnal`  VALUES ( "146","hftrbk8mhln314fappri14f7q4","K/006","Item Masuk","2000","0","");


--
-- Tabel structure for table `tbs_jurnal_trans`
--
DROP TABLE  IF EXISTS `tbs_jurnal_trans`;
CREATE TABLE `tbs_jurnal_trans` (
  `id` int(11) NOT NULL,
  `no_jurnal` int(11) NOT NULL,
  `waktu_jurnal` int(11) NOT NULL,
  `ket_jurnal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_kas_keluar`
--
DROP TABLE  IF EXISTS `tbs_kas_keluar`;
CREATE TABLE `tbs_kas_keluar` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `dari_akun` varchar(100) NOT NULL,
  `ke_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=latin1;

INSERT INTO `tbs_kas_keluar`  VALUES ( "182","","1/KK/08/16","","K/001","K/003","10000","2016-08-23","15:28:15","admin");


--
-- Tabel structure for table `tbs_kas_masuk`
--
DROP TABLE  IF EXISTS `tbs_kas_masuk`;
CREATE TABLE `tbs_kas_masuk` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `dari_akun` varchar(100) NOT NULL,
  `ke_akun` varchar(100) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `tbs_kas_masuk`  VALUES ( "36","9pbjp0af86stfs8bqrafjlfq15","","","K/002","K/001","1000","2016-08-24","13:46:23","admin");


--
-- Tabel structure for table `tbs_pembayaran_hutang`
--
DROP TABLE  IF EXISTS `tbs_pembayaran_hutang`;
CREATE TABLE `tbs_pembayaran_hutang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur_pembayaran` varchar(100) NOT NULL,
  `no_faktur_pembelian` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date NOT NULL,
  `kredit` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `jumlah_bayar` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_pembayaran_piutang`
--
DROP TABLE  IF EXISTS `tbs_pembayaran_piutang`;
CREATE TABLE `tbs_pembayaran_piutang` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur_pembayaran` varchar(100) NOT NULL,
  `no_faktur_penjualan` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `tanggal_jt` date NOT NULL,
  `kredit` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `jumlah_bayar` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_pembelian`
--
DROP TABLE  IF EXISTS `tbs_pembelian`;
CREATE TABLE `tbs_pembelian` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(50) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` int(50) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `harga` int(50) NOT NULL,
  `subtotal` int(50) NOT NULL,
  `potongan` int(50) DEFAULT NULL,
  `tax` int(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbs_pembelian`  VALUES ( "3","","4/BL/08/16","BB1","CUP 240ML DELTAPACK","10","PCS","150","1300","200","0");


--
-- Tabel structure for table `tbs_penjualan`
--
DROP TABLE  IF EXISTS `tbs_penjualan`;
CREATE TABLE `tbs_penjualan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` int(25) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `harga` int(50) NOT NULL,
  `subtotal` int(50) NOT NULL,
  `potongan` int(50) NOT NULL,
  `tax` int(50) NOT NULL,
  `hpp` int(100) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `no_pesanan` int(100) NOT NULL,
  `komentar` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_retur_pembelian`
--
DROP TABLE  IF EXISTS `tbs_retur_pembelian`;
CREATE TABLE `tbs_retur_pembelian` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur_retur` varchar(100) NOT NULL,
  `no_faktur_pembelian` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `jumlah_beli` int(100) NOT NULL,
  `jumlah_retur` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_retur_penjualan`
--
DROP TABLE  IF EXISTS `tbs_retur_penjualan`;
CREATE TABLE `tbs_retur_penjualan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur_retur` varchar(100) NOT NULL,
  `no_faktur_penjualan` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `jumlah_beli` int(100) NOT NULL,
  `jumlah_retur` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `subtotal` int(100) NOT NULL,
  `potongan` int(100) NOT NULL,
  `tax` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_stok_awal`
--
DROP TABLE  IF EXISTS `tbs_stok_awal`;
CREATE TABLE `tbs_stok_awal` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah_awal` int(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `user` varchar(100) NOT NULL,
  `tanggal_edit` varchar(100) DEFAULT NULL,
  `user_edit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `tbs_stok_opname`
--
DROP TABLE  IF EXISTS `tbs_stok_opname`;
CREATE TABLE `tbs_stok_opname` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `no_faktur` varchar(100) NOT NULL,
  `kode_barang` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `awal` int(100) NOT NULL,
  `masuk` int(100) NOT NULL,
  `keluar` int(100) NOT NULL,
  `stok_sekarang` int(100) NOT NULL,
  `fisik` int(100) NOT NULL,
  `selisih_fisik` int(100) NOT NULL,
  `selisih_harga` int(100) NOT NULL,
  `harga` int(100) NOT NULL,
  `hpp` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `user`
--
DROP TABLE  IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `otoritas` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_sales` varchar(100) NOT NULL,
  `lihat_penjualan` varchar(100) NOT NULL,
  `edit_penjualan` varchar(100) NOT NULL,
  `tambah_penjualan` varchar(100) NOT NULL,
  `hapus_penjualan` varchar(100) NOT NULL,
  `lihat_pembelian` varchar(100) NOT NULL,
  `edit_pembelian` varchar(100) NOT NULL,
  `tambah_pembelian` varchar(100) NOT NULL,
  `hapus_pembelian` varchar(100) NOT NULL,
  `lihat_master_data` varchar(100) NOT NULL,
  `edit_master_data` varchar(100) NOT NULL,
  `hapus_master_data` varchar(100) NOT NULL,
  `tambah_master_data` varchar(100) NOT NULL,
  `lihat_item_masuk` varchar(100) NOT NULL,
  `edit_item_masuk` varchar(100) NOT NULL,
  `hapus_item_masuk` varchar(100) NOT NULL,
  `tambah_item_masuk` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;

INSERT INTO `user`  VALUES ( "99","admin","$2y$10$M3IhwkleMCVrgYo.HqfL6eBx5yfli3WNfR.PsoyO0NV3ya/hxcKwe","Team 3","Bandar Lampung","Pimpinan","Pimpinan","aktif","Tidak","","","","","","","","","","","","","","","","");
INSERT INTO `user`  VALUES ( "116","IT","$2y$10$nTNVekV5RPMmKrpSUeGzYuXiT06wWxb2yCAra/zryp.WOsR7Z.YjW","IT DEV","Bandar Lampung","Pimpinan","Pimpinan","aktif","Tidak","","","","","","","","","","","","","","","","");
INSERT INTO `user`  VALUES ( "117","Develop","$2y$10$LDdRIW9RVX01Crwx.nWsS.KW2.tiIvkF7PjET22AesnBQ2Y5ewyU.","Dev 3","Bandar Lampung","Pimpinan","Cashier","aktif","Iya","","","","","","","","","","","","","","","","");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
